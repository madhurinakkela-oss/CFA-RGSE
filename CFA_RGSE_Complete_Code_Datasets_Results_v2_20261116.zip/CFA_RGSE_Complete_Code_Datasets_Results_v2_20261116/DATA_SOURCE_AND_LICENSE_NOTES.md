# Data Source and Reuse Notes

## Central Electricity Authority sources

The state fly-ash table, thermal-power station table, and indicative major
cement-plant list were transcribed from Central Electricity Authority reports
and annexures. The package preserves source-oriented fields and audit notes.

Reference page:

https://cea.nic.in/notification/ash-generation-and-utilization-at-coal-liginite-based-grid-connected-thermal-power-stations-for-the-year-2024-25/?lang=en

## Cement-plant geometry source

The 380-row cement-plant file is based on the Esri India Living Atlas cement
plant layer. It is India-focused but must not be described as an official
Government of India plant registry.

Reference service:

https://livingatlas.esri.in/server/rest/services/Cement_Plants_in_India_2024/MapServer/0

## Reuse boundary

This research archive is supplied for reproducibility and audit. Before public
redistribution, commercial use, or operational decision-making, users should
verify the current terms, attribution requirements, and later revisions of
each original source. Model-estimated capacity and production values do not
replace statutory filings, company records, laboratory testing, or field
verification.
