# CFA-RGSE Complete Reproducibility Package

This archive contains the datasets, source code, notebooks, machine-readable
results, statistical outputs, and publication figures used in the CFA-RGSE
cement--fly-ash study and its later graph/allocation extension.

## Evidence boundary

The archive deliberately separates two result sets:

1. **Core manuscript study** -- the results reported in
   `manuscripts/CFA_RGSE_HA_final.docx`. These include the audited 380 x 53
   table, the reliability-gated CFA-RGSE model, state-held-out baselines and
   ablations, 108 missing-capacity estimates, and the 341-plant transparent
   priority screen.
2. **Optional graph and allocation extension** -- nested graph spatial-lag
   experiments and annual-data allocation scenarios. These outputs are
   included for reproducibility but must not be presented as road-network,
   real-time, causal, or investment-feasibility results.

## Archive structure

- `cfa_pkg/data/raw/` -- four source CSV files.
- `cfa_pkg/data/processed/` -- audited 380 x 53 modelling table and QA files.
- `cfa_pkg/scripts/` -- core dataset, modelling, ablation, statistical, and
  priority-index code.
- `cfa_pkg/notebooks/` -- Colab entry notebook.
- `cfa_pkg/results/` -- fold metrics, OOF predictions, missing-value estimates,
  paired statistics, graph outputs, allocation outputs, and base plots.
- `output/q1_extension_figures/` -- 500-dpi PNG/TIFF figures plus SVG versions.
- `run_graph_spatial_lag_experiment.py` -- exploratory graph-scale study.
- `run_nested_graph_scale_experiment.py` -- nested state-grouped graph-scale
  selection used for the confirmatory graph result.
- `build_q1_extension_artifacts.py` -- constrained allocation and figure builder.
- `run_cfa_rgse_complete.py` -- one-command workflow.
- `validate_cfa_rgse_package.py` -- independent count/result/artifact checks.
- `VALIDATION_REPORT.json` -- generated validation outcome.
- `SHA256SUMS.txt` and `FILE_MANIFEST.csv` -- archive integrity records.

## Verified dataset counts

| Dataset | Rows |
|---|---:|
| Cement plants in India 2024 | 380 |
| CEA thermal-power plants 2024-25 | 189 |
| CEA statewise fly ash 2024-25 | 18 |
| CEA major cement plants 2025 | 141 |

The processed table has 380 rows and 53 columns, with 272 installed-capacity
labels and 115 positive production labels.

## Installation

Python 3.10 or later is recommended.

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r cfa_pkg/requirements.txt
```

## Execution

Reproduce only the core manuscript outputs:

```bash
python run_cfa_rgse_complete.py --core-only
```

Reproduce the core study and the graph/allocation extension:

```bash
python run_cfa_rgse_complete.py
```

Run validation without retraining:

```bash
python validate_cfa_rgse_package.py
```

All model seeds are fixed at 42. Runtime can vary by CPU and scikit-learn
version. Minor floating-point differences may occur, but the validation script
checks the frozen package outputs against the reported values.

## Main frozen findings

- Core CFA-RGSE capacity RMSE: 1.303 MTPA.
- Random Forest capacity RMSE: 1.320 MTPA.
- No-fly-ash tabular ablation RMSE: 1.298 MTPA.
- Nested graph extension RMSE: 1.295 MTPA.
- Core missing-capacity completions: 108.
- Core priority-screen rows: 341.
- Annual baseline allocation scenario: 24.260 Mt across 113 positive links.

The core capacity improvement over Random Forest is not statistically decisive.
The allocation outputs use straight-line distance and declared scenario
assumptions; they are not verified transport plans.

## Data-source notes

The CEA files are Government of India records. The cement-plant geometry layer
is India-specific and published by Esri India; it is not a Government of India
registry. Users must review the original providers' terms before redistribution
or operational use. Source URLs and limitations are documented in
`cfa_pkg/README.md` and `DATA_SOURCE_AND_LICENSE_NOTES.md`.
