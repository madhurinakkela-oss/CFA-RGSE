#!/usr/bin/env python3
"""Build reviewer-safe graph, mass-balance, and scenario figures.

Empirical claims are restricted to the state-held-out graph experiment.
Allocation and seasonal layers are explicitly labelled as annual-data scenarios.
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, vstack

ROOT = Path(__file__).resolve().parent
PKG = ROOT / "cfa_pkg"
OUT = ROOT / "output" / "q1_extension_figures"
RESULTS = PKG / "results" / "q1_extension"
OUT.mkdir(parents=True, exist_ok=True)
RESULTS.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(PKG / "scripts"))

import train_capacity_models as base  # noqa: E402
from run_graph_spatial_lag_experiment import build_graph_features, haversine_matrix  # noqa: E402


BLUE = "#1F4E79"
LIGHT_BLUE = "#DDEBF7"
TEAL = "#008C95"
ORANGE = "#D55E00"
GREEN = "#2A7F62"
GRAY = "#6B7280"
LIGHT_GRAY = "#E5E7EB"
DARK = "#111827"


def set_style():
    mpl.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 8.5,
        "axes.titlesize": 10.5,
        "axes.labelsize": 9,
        "xtick.labelsize": 7.5,
        "ytick.labelsize": 7.5,
        "legend.fontsize": 7.5,
        "axes.linewidth": 0.8,
        "axes.edgecolor": "#374151",
        "axes.titleweight": "bold",
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "savefig.facecolor": "white",
        "savefig.bbox": "tight",
    })


def save_figure(fig, stem):
    fig.savefig(OUT / f"{stem}.png", dpi=500, bbox_inches="tight", pad_inches=0.04)
    fig.savefig(OUT / f"{stem}.tiff", dpi=500, bbox_inches="tight", pad_inches=0.04,
                pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(OUT / f"{stem}.svg", bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)


def add_panel_label(ax, label):
    ax.text(-0.08, 1.06, label, transform=ax.transAxes, fontsize=10.5,
            fontweight="bold", va="top", ha="left")


def fit_graph_missing_predictions(data, graph):
    augmented = pd.concat([data.reset_index(drop=True), graph.reset_index(drop=True)], axis=1)
    graph_cols = list(graph.columns)
    original_views = dict(base.VIEW_FEATURES)
    base.VIEW_FEATURES = dict(original_views)
    base.VIEW_FEATURES["graph"] = base.CORE_FEATURES + graph_cols
    labelled = augmented.loc[augmented[base.TARGET].notna()].reset_index(drop=True)
    missing = augmented.loc[augmented[base.TARGET].isna()].reset_index(drop=True)
    y = labelled[base.TARGET].to_numpy(float)
    groups = labelled[base.GROUP].to_numpy()
    view_data = base.inner_view_predictions(labelled, y, groups, missing, base.SEED + 12000)
    active = ["plant", "tpp", "major", "graph"]
    pred, spread, weights = base.predict_variant(
        view_data, labelled, y, missing, active, True, False
    )
    result = missing[[
        "objectid", "uid", "name", "district", "state_canonical",
        "centroid_longitude", "centroid_latitude", "nearest_tpp_distance_km",
        "state_ash_generation_lmt", "cea_major_match_high_confidence",
    ]].copy()
    result["predicted_capacity_mtpa"] = pred
    result["model_spread_mtpa"] = spread
    for idx, view in enumerate(active):
        result[f"weight_{view}"] = weights[:, idx]
    result["prediction_status"] = "graph spatial-lag model estimate; source capacity missing"
    result.to_csv(RESULTS / "capacity_missing_predictions_graph.csv", index=False)
    base.VIEW_FEATURES = original_views
    return result


def build_priority(data, missing_pred):
    pred = missing_pred[["objectid", "predicted_capacity_mtpa", "model_spread_mtpa"]]
    frame = data.merge(pred, on="objectid", how="left", validate="one_to_one")
    frame["capacity_used_mtpa"] = frame["capacity_mtpa_target"].fillna(frame["predicted_capacity_mtpa"])
    frame["capacity_value_type"] = np.where(frame["capacity_label_available"].eq(1), "observed", "model_estimated")
    frame["state_unutilised_flyash_lmt"] = (
        frame["state_ash_generation_lmt"] - frame["state_ash_utilisation_lmt"]
    ).clip(lower=0)
    scoreable = frame["state_flyash_data_available"].eq(1)
    specs = {
        "component_cement_capacity": ("capacity_used_mtpa", True),
        "component_state_unutilised_flyash": ("state_unutilised_flyash_lmt", True),
        "component_tpp_capacity_100km": ("tpp_capacity_within_100km_mw", True),
        "component_tpp_proximity": ("nearest_tpp_distance_km", False),
    }
    for out_col, (src, ascending) in specs.items():
        frame[out_col] = np.nan
        frame.loc[scoreable, out_col] = frame.loc[scoreable, src].rank(
            method="average", pct=True, ascending=ascending
        )
    frame["linkage_priority_score"] = 100 * (
        0.35 * frame["component_cement_capacity"]
        + 0.30 * frame["component_state_unutilised_flyash"]
        + 0.20 * frame["component_tpp_capacity_100km"]
        + 0.15 * frame["component_tpp_proximity"]
    )
    frame["linkage_priority_rank"] = frame["linkage_priority_score"].rank(method="min", ascending=False)
    frame.to_csv(RESULTS / "linkage_priority_graph_predictions.csv", index=False)
    return frame


def state_residual_supply(flyash):
    f = flyash.loc[~flyash["state"].astype(str).str.contains("Grand Total", case=False, na=False)].copy()
    aliases = {"MP": "Madhya Pradesh", "UP": "Uttar Pradesh"}
    f["state_canonical"] = f["state"].replace(aliases)
    f["residual_supply_mt"] = (
        f["ash_generation_lmt"] - f["ash_utilisation_lmt"]
    ).clip(lower=0) * 0.1
    return f.set_index("state_canonical")["residual_supply_mt"].to_dict()


def prepare_network(priority, tpp, flyash):
    plants = priority.loc[
        priority["capacity_used_mtpa"].notna()
        & priority[["centroid_latitude", "centroid_longitude"]].notna().all(axis=1)
    ].copy().reset_index(drop=True)
    plants["demand_cap_mt"] = 0.35 * plants["capacity_used_mtpa"].clip(lower=0)
    tpp = tpp.loc[tpp[["latitude", "longitude", "capacity_mw"]].notna().all(axis=1)].copy().reset_index(drop=True)
    tpp["state_canonical"] = tpp["state"].replace({"MP": "Madhya Pradesh", "UP": "Uttar Pradesh"})
    supply_map = state_residual_supply(flyash)
    state_cap = tpp.groupby("state_canonical")["capacity_mw"].transform("sum")
    tpp["residual_supply_mt"] = tpp["state_canonical"].map(supply_map).fillna(0.0) * tpp["capacity_mw"] / state_cap
    tpp["residual_supply_mt"] = tpp["residual_supply_mt"].fillna(0.0)
    distances = haversine_matrix(
        tpp["latitude"], tpp["longitude"],
        plants["centroid_latitude"], plants["centroid_longitude"],
    )
    return plants, tpp, distances


def solve_allocation(plants, tpp, distances, supply_multiplier=1.0,
                     max_distance=500.0, border_penalty_km=0.0):
    supply_idx = np.flatnonzero(tpp["residual_supply_mt"].to_numpy(float) > 1e-10)
    demand_idx = np.flatnonzero(plants["demand_cap_mt"].to_numpy(float) > 1e-10)
    edges = []
    for ti in supply_idx:
        js = demand_idx[distances[ti, demand_idx] <= max_distance]
        for pj in js:
            cross = float(str(tpp.loc[ti, "state_canonical"]) != str(plants.loc[pj, "state_canonical"]))
            edges.append((ti, pj, float(distances[ti, pj]), cross))
    if not edges:
        raise RuntimeError("No feasible TPP-cement edges for allocation scenario")
    m = len(edges)
    rows, cols, vals = [], [], []
    supply_pos = {idx: pos for pos, idx in enumerate(supply_idx)}
    demand_pos = {idx: pos for pos, idx in enumerate(demand_idx)}
    ns = len(supply_idx)
    for k, (ti, pj, _d, _cross) in enumerate(edges):
        rows.extend([supply_pos[ti], ns + demand_pos[pj]])
        cols.extend([k, k])
        vals.extend([1.0, 1.0])
    A = coo_matrix((vals, (rows, cols)), shape=(ns + len(demand_idx), m)).tocsr()
    b = np.concatenate([
        tpp.loc[supply_idx, "residual_supply_mt"].to_numpy(float) * supply_multiplier,
        plants.loc[demand_idx, "demand_cap_mt"].to_numpy(float),
    ])
    max_result = linprog(-np.ones(m), A_ub=A, b_ub=b, bounds=(0, None), method="highs")
    if not max_result.success:
        raise RuntimeError(max_result.message)
    max_flow = float(max_result.x.sum())
    costs = np.array([d + border_penalty_km * cross for _ti, _pj, d, cross in edges])
    Aeq = coo_matrix(np.ones((1, m))).tocsr()
    min_result = linprog(costs, A_ub=A, b_ub=b, A_eq=Aeq, b_eq=[max_flow], bounds=(0, None), method="highs")
    if not min_result.success:
        x = max_result.x
    else:
        x = min_result.x
    link_rows = []
    for amount, (ti, pj, d, cross), cost in zip(x, edges, costs):
        if amount <= 1e-8:
            continue
        link_rows.append({
            "tpp_index": int(ti), "plant_index": int(pj),
            "tpp_name": tpp.loc[ti, "tpp_tps_name"],
            "plant_objectid": int(plants.loc[pj, "objectid"]),
            "tpp_state": tpp.loc[ti, "state_canonical"],
            "plant_state": plants.loc[pj, "state_canonical"],
            "distance_km": d, "cross_state": int(cross),
            "impedance_km_equivalent": cost,
            "allocated_mt": float(amount),
        })
    links = pd.DataFrame(link_rows)
    plant_alloc = links.groupby("plant_index").agg(
        allocated_mt=("allocated_mt", "sum"),
        transport_work_mt_km=("distance_km", lambda s: 0.0),
    ) if not links.empty else pd.DataFrame(columns=["allocated_mt"])
    if not links.empty:
        weighted = links.assign(work=links["allocated_mt"] * links["distance_km"])
        work = weighted.groupby("plant_index")["work"].sum()
        plant_alloc["transport_work_mt_km"] = work
    result = plants.copy()
    result["allocated_mt"] = result.index.to_series().map(plant_alloc.get("allocated_mt", pd.Series(dtype=float))).fillna(0.0)
    result["transport_work_mt_km"] = result.index.to_series().map(plant_alloc.get("transport_work_mt_km", pd.Series(dtype=float))).fillna(0.0)
    result["mean_distance_km"] = np.where(
        result["allocated_mt"] > 0,
        result["transport_work_mt_km"] / result["allocated_mt"], np.nan,
    )
    result["demand_served_percent"] = 100 * result["allocated_mt"] / result["demand_cap_mt"].replace(0, np.nan)
    return result, links, max_flow


def bootstrap_differences(iterations=20000, seed=20261111):
    orig = pd.read_csv(PKG / "results/capacity_group_cv_oof_predictions.csv")
    graph = pd.read_csv(PKG / "results/nested_graph_extension/nested_graph_oof_predictions.csv")
    proposed = "CFA-RGSE-GSL nested no fly-ash"
    base_name = "RandomForest"
    oof = pd.concat([orig.loc[orig.model.eq(base_name)], graph.loc[graph.model.eq(proposed)]])
    pivot = oof.pivot(index=["objectid", "state_canonical", "y_true"], columns="model", values="y_pred").dropna().reset_index()
    states = pivot["state_canonical"].unique()
    stats = []
    for state in states:
        f = pivot.loc[pivot.state_canonical.eq(state)]
        y = f.y_true.to_numpy(float)
        stats.append([len(f), np.square(y-f[proposed].to_numpy(float)).sum(), np.square(y-f[base_name].to_numpy(float)).sum()])
    stats = np.asarray(stats, float)
    rng = np.random.default_rng(seed)
    draws = rng.integers(0, len(states), size=(iterations, len(states)))
    sampled = stats[draws].sum(axis=1)
    return np.sqrt(sampled[:,1]/sampled[:,0]) - np.sqrt(sampled[:,2]/sampled[:,0])


def figure_graph_benchmark():
    orig = pd.read_csv(PKG / "results/capacity_group_cv_summary.csv")
    graph = pd.read_csv(PKG / "results/nested_graph_extension/nested_graph_summary.csv")
    selected = [
        ("Random Forest", orig.loc[orig.model.eq("RandomForest")].iloc[0]),
        ("CFA-RGSE full", orig.loc[orig.model.eq("CFA-RGSE (full)")].iloc[0]),
        ("CFA-RGSE no fly-ash", orig.loc[orig.model.eq("w/o fly-ash view")].iloc[0]),
        ("CFA-RGSE-GSL nested", graph.iloc[0]),
    ]
    labels = [x[0] for x in selected]
    means = np.array([float(x[1].rmse_mean) for x in selected])
    stds = np.array([float(x[1].rmse_std) for x in selected])
    order = np.argsort(means)[::-1]
    labels = [labels[i] for i in order]
    means, stds = means[order], stds[order]
    colors = [BLUE if "GSL" in x else "#AAB4BF" for x in labels]

    diffs = bootstrap_differences()
    lo, hi = np.quantile(diffs, [0.025, 0.975])
    mean = diffs.mean()
    fig, axes = plt.subplots(1, 2, figsize=(7.48, 3.45), gridspec_kw={"width_ratios": [1.08, 0.92]})
    ax = axes[0]
    y = np.arange(len(labels))
    ax.barh(y, means, xerr=stds, color=colors, edgecolor="white", linewidth=0.8, capsize=2.5)
    ax.set_yticks(y, labels)
    ax.set_xlabel("Fold-mean RMSE (MTPA; lower is better)")
    ax.set_title("State-held-out benchmark", loc="left")
    ax.grid(axis="x", color=LIGHT_GRAY, linewidth=0.7)
    ax.set_axisbelow(True)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.set_xlim(0, max(means+stds)*1.12)
    for yi, val in zip(y, means):
        ax.text(val+0.012, yi, f"{val:.3f}", va="center", fontsize=7.3)
    add_panel_label(ax, "a")

    ax = axes[1]
    ax.hist(diffs, bins=42, density=True, color=LIGHT_BLUE, edgecolor=BLUE, linewidth=0.45)
    ax.axvline(0, color=DARK, linestyle="--", linewidth=1.0, label="No difference")
    ax.axvline(mean, color=ORANGE, linewidth=1.4, label=f"Mean = {mean:.3f}")
    ax.axvspan(lo, hi, color=ORANGE, alpha=0.12, label=f"95% CI [{lo:.3f}, {hi:.3f}]")
    ax.set_xlabel("Pooled RMSE difference (GSL − RF)")
    ax.set_ylabel("Bootstrap density")
    ax.set_title("State-cluster bootstrap", loc="left")
    ax.legend(frameon=False, loc="upper left")
    ax.grid(axis="y", color=LIGHT_GRAY, linewidth=0.7)
    ax.spines[["top", "right"]].set_visible(False)
    add_panel_label(ax, "b")
    fig.tight_layout(w_pad=2.2, pad=0.4)
    save_figure(fig, "Fig10_Graph_Benchmark_and_Uncertainty")


def pareto_front(x, y):
    order = np.argsort(x)
    keep = []
    best = -np.inf
    for i in order:
        if np.isfinite(x[i]) and np.isfinite(y[i]) and y[i] > best + 1e-9:
            keep.append(i)
            best = y[i]
    return np.asarray(keep, int)


def figure_pareto(plants, tpp, distances, baseline):
    positive = baseline.loc[baseline.allocated_mt > 1e-6].copy()
    x = positive.mean_distance_km.to_numpy(float)
    y = positive.demand_served_percent.clip(upper=100).to_numpy(float)
    front = pareto_front(x, y)
    sizes = 18 + 110 * np.sqrt(positive.allocated_mt.to_numpy(float) / positive.allocated_mt.max())
    observed = positive.capacity_value_type.eq("observed").to_numpy()

    caps = [100, 150, 200, 300, 400, 500, 600]
    trade = []
    total_supply = tpp.residual_supply_mt.sum()
    for cap in caps:
        _p, links, flow = solve_allocation(plants, tpp, distances, max_distance=float(cap))
        work = float((links.allocated_mt * links.distance_km).sum()) if not links.empty else 0.0
        trade.append((cap, flow, 100*flow/total_supply if total_supply else np.nan, work/flow if flow else np.nan))
    trade = pd.DataFrame(trade, columns=["route_cap_km", "allocated_mt", "supply_utilised_percent", "mean_distance_km"])
    trade.to_csv(RESULTS / "mass_balance_route_cap_tradeoff.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(7.48, 3.45), gridspec_kw={"width_ratios": [1.08, 0.92]})
    ax = axes[0]
    ax.scatter(x[~observed], y[~observed], s=sizes[~observed], c=ORANGE, marker="^",
               alpha=0.72, edgecolors="white", linewidths=0.4, label="Model-estimated capacity")
    ax.scatter(x[observed], y[observed], s=sizes[observed], c=BLUE, marker="o",
               alpha=0.62, edgecolors="white", linewidths=0.4, label="Observed capacity")
    if len(front):
        idx = front[np.argsort(x[front])]
        ax.plot(x[idx], y[idx], color=DARK, linewidth=1.4, marker="D", markersize=3,
                label="Non-dominated screen")
    ax.set_xlabel("Mean Haversine transport proxy (km)")
    ax.set_ylabel("Plant blending-demand cap served (%)")
    ax.set_title("Plant-level mass-balance screen", loc="left")
    ax.grid(color=LIGHT_GRAY, linewidth=0.7)
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(frameon=False, loc="lower right")
    add_panel_label(ax, "a")

    ax = axes[1]
    ax.plot(trade.mean_distance_km, trade.supply_utilised_percent, color=TEAL,
            marker="o", markersize=5, linewidth=1.8)
    grouped = []
    for (_x, _y), group in trade.groupby([
        trade.mean_distance_km.round(5), trade.supply_utilised_percent.round(5)
    ]):
        caps_here = sorted(group.route_cap_km.astype(int).tolist())
        label = (f"{caps_here[0]}–{caps_here[-1]} km" if len(caps_here) > 1
                 else f"{caps_here[0]} km")
        grouped.append((float(group.mean_distance_km.iloc[0]),
                        float(group.supply_utilised_percent.iloc[0]), label))
    for gx, gy, label in grouped:
        ax.annotate(label, (gx, gy), xytext=(3, 4), textcoords="offset points", fontsize=6.8)
    ax.set_xlabel("Allocation-weighted mean distance (km)")
    ax.set_ylabel("Residual ash supply allocated (%)")
    ax.set_title("System trade-off by route cap", loc="left")
    ax.grid(color=LIGHT_GRAY, linewidth=0.7)
    ax.spines[["top", "right"]].set_visible(False)
    add_panel_label(ax, "b")
    fig.tight_layout(w_pad=2.2, pad=0.4)
    save_figure(fig, "Fig11_Mass_Balance_Pareto_Screen")


def figure_scenarios(plants, tpp, distances):
    scenarios = [
        ("Annual baseline", 1.00, 0.0),
        ("Peak-generation stress", 1.10, 10.0),
        ("Monsoon supply stress", 0.80, 40.0),
        ("Recovery stress", 0.95, 20.0),
    ]
    scenario_frames = []
    summaries = []
    for name, supply_mult, border_penalty in scenarios:
        frame, links, flow = solve_allocation(
            plants, tpp, distances, supply_multiplier=supply_mult,
            max_distance=500.0, border_penalty_km=border_penalty,
        )
        frame["scenario"] = name
        scenario_frames.append(frame)
        summaries.append({
            "scenario": name, "supply_multiplier": supply_mult,
            "border_penalty_km_equivalent": border_penalty,
            "allocated_mt": flow,
            "mean_distance_km": float((links.allocated_mt*links.distance_km).sum()/flow) if flow else np.nan,
            "cross_state_share": float(links.loc[links.cross_state.eq(1), "allocated_mt"].sum()/flow) if flow else np.nan,
        })
    pd.DataFrame(summaries).to_csv(RESULTS / "seasonal_scenario_summary.csv", index=False)
    all_frames = pd.concat(scenario_frames, ignore_index=True)
    all_frames[["objectid", "scenario", "allocated_mt", "demand_cap_mt", "demand_served_percent"]].to_csv(
        RESULTS / "seasonal_scenario_plant_allocations.csv", index=False
    )

    fig, axes = plt.subplots(2, 2, figsize=(7.48, 5.25), sharex=True, sharey=True)
    norm = mpl.colors.Normalize(vmin=0, vmax=100)
    cmap = mpl.colormaps["viridis"]
    for ax, (name, _sm, _bp), frame, lab in zip(axes.flat, scenarios, scenario_frames, ["a", "b", "c", "d"]):
        ax.scatter(tpp.longitude, tpp.latitude, marker="^", s=9, c="#B8BEC6", alpha=0.45,
                   linewidths=0, label="Thermal station")
        p = ax.scatter(frame.centroid_longitude, frame.centroid_latitude,
                       c=frame.demand_served_percent.clip(0,100), cmap=cmap, norm=norm,
                       s=17, edgecolors="white", linewidths=0.25, alpha=0.9)
        ax.set_title(name, loc="left", fontsize=9.2)
        ax.grid(color=LIGHT_GRAY, linewidth=0.45)
        ax.spines[["top", "right"]].set_visible(False)
        add_panel_label(ax, lab)
    for ax in axes[-1, :]: ax.set_xlabel("Longitude")
    for ax in axes[:, 0]: ax.set_ylabel("Latitude")
    cbar = fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=axes, fraction=0.025, pad=0.02)
    cbar.set_label("Plant blending-demand cap served (%)")
    fig.subplots_adjust(left=0.08, right=0.91, bottom=0.08, top=0.95, wspace=0.12, hspace=0.18)
    save_figure(fig, "Fig12_Scenario_Geospatial_Stress_Surfaces")


def draw_architecture():
    fig, ax = plt.subplots(figsize=(7.48, 5.25))
    ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")
    def box(x, y, w, h, title, lines, face="white", edge=BLUE, lw=1.2,
            title_color=DARK, title_size=6.2, text_size=4.6):
        p = FancyBboxPatch((x,y), w,h, boxstyle="round,pad=0.35,rounding_size=0.8",
                           facecolor=face, edgecolor=edge, linewidth=lw)
        ax.add_patch(p)
        ax.text(x+w/2, y+h-1.8, title, ha="center", va="top", fontsize=title_size,
                fontweight="bold", color=title_color)
        for i, line in enumerate(lines):
            ax.text(x+w/2, y+h-4.6-2.35*i, line, ha="center", va="top",
                    fontsize=text_size, color=DARK)
        return p
    def arrow(x1,y1,x2,y2,style="-"):
        ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle="-|>",mutation_scale=9,
                                     linewidth=1.0, color=DARK, linestyle=style,
                                     connectionstyle="arc3,rad=0.0"))
    ax.text(50, 98.4, "CFA-RGSE-GSL: GRAPH IMPUTATION AND CONSTRAINED ALLOCATION",
            ha="center", va="top", fontsize=9.0, fontweight="bold", color=DARK)
    ax.text(50, 95.4, "Empirical graph benchmark with scenario-labelled logistics and temporal stress layers",
            ha="center", va="top", fontsize=5.5, color=GRAY)
    xs=[2,26.5,51,75.5]
    titles=["CEMENT PLANTS", "STATE FLY ASH", "THERMAL STATIONS", "CEA MAJOR LIST"]
    contents=[
        ["380 plants", "272 labels · 108 gaps"],
        ["17 states + India", "annual aggregates"],
        ["189 records", "188 valid coordinates"],
        ["141 records", "24 positive matches"],
    ]
    for x,t,c in zip(xs,titles,contents):
        box(x,82,22.5,9,t,c,LIGHT_BLUE,title_size=5.9,text_size=4.3)
        arrow(x+11.25,82,x+11.25,78.5)
    box(13,71.5,74,6.5,"AUDIT AND HARMONISATION  380 × 53",
        ["Aliases · coordinate QA · provenance · missingness · conservative matching"],
        "#F7F7F7",DARK,1.2,title_size=6.4,text_size=4.4)
    arrow(35,71.5,35,68); arrow(65,71.5,65,68)
    box(4,56,42,12,"RELIABILITY-GATED TABULAR VIEWS",
        ["plant · fly ash · TPP · major list", "state-grouped OOF error", "tree spread + availability"],
        "white",BLUE,title_size=6.2,text_size=4.4)
    box(54,56,42,12,"BIPARTITE GRAPH SPATIAL-LAG VIEW",
        ["cement ↔ thermal nodes", "coordinate-capacity kernels", "target-free graph contrasts"],
        "white",TEAL,title_size=6.2,text_size=4.4)
    arrow(25,56,39,51.5); arrow(75,56,61,51.5)
    box(27,43,46,8.5,"OBSERVATION-SPECIFIC FUSION",
        ["reliability-weighted tabular + graph predictions", "best variant omits the direct fly-ash expert"],
        "#EEF7F7",TEAL,1.4,title_size=6.4,text_size=4.5)
    arrow(50,43,50,39)
    box(6,28,40,11,"CAPACITY COMPLETION",
        ["108 missing values", "row weights + ensemble spread", "nested state-held-out RMSE 1.295 MTPA"],
        "#F8FAFC",BLUE,title_size=6.5,text_size=4.5)
    box(54,28,40,11,"MASS-BALANCE ALLOCATION",
        ["supply ≤ residual ash", "demand ≤ 35% PPC cap", "max-flow, then minimum impedance"],
        "#FFF7ED",ORANGE,title_size=6.5,text_size=4.5)
    arrow(50,39,26,39); arrow(50,39,74,39)
    arrow(26,28,26,24.5); arrow(74,28,74,24.5)
    box(6,14,40,10.5,"AUDITABLE OUTPUTS",
        ["capacity estimates · Pareto front", "allocation flows · stress surfaces", "verification priorities only"],
        "#F3F4F6",DARK,title_size=6.3,text_size=4.4)
    box(54,14,40,10.5,"LOGISTICS AND TEMPORAL SCENARIOS",
        ["current: straight-line sensitivity", "planned: OSRM/ORS + rail tariffs", "not real-time validation"],
        "#FFF7ED",ORANGE,title_size=6.0,text_size=4.4)
    box(3,1.5,94,8.5,"EVIDENCE BOUNDARY",
        ["Empirical: graph capacity model. Scenario only: mass balance and annual stress.",
         "Road/rail cost, CO₂, ROI, and real-time dispatch require new data."],
        "#F9FAFB",DARK,1.0,title_size=6.2,text_size=4.0)
    fig.tight_layout(pad=0.2)
    save_figure(fig, "Fig03_CFA_RGSE_GSL_Architecture")


def main():
    set_style()
    data = pd.read_csv(PKG / "data/processed/cement_flyash_model_dataset.csv")
    tpp = pd.read_csv(PKG / "data/raw/CEA_Thermal_Power_Plants_2024_25.csv")
    flyash = pd.read_csv(PKG / "data/raw/CEA_Statewise_Fly_Ash_2024_25.csv")
    graph = build_graph_features(data, tpp, tau_km=75.0, top_k=8)
    missing_pred = fit_graph_missing_predictions(data, graph)
    priority = build_priority(data, missing_pred)
    plants, tpp_network, distances = prepare_network(priority, tpp, flyash)
    baseline, links, flow = solve_allocation(plants, tpp_network, distances, max_distance=500.0)
    baseline.to_csv(RESULTS / "baseline_mass_balance_plant_allocation.csv", index=False)
    links.to_csv(RESULTS / "baseline_mass_balance_links.csv", index=False)
    (RESULTS / "allocation_manifest.json").write_text(json.dumps({
        "allocation_mt": flow,
        "supply_source": "positive state residual = max(generation - utilisation, 0), converted from LMT to Mt",
        "tpp_apportionment": "state residual apportioned to TPPs in proportion to installed MW",
        "plant_demand_cap": "0.35 × observed or graph-estimated cement capacity",
        "distance": "Haversine proxy; no road/rail claim",
        "optimisation": "maximise feasible allocation, then minimise total distance under supply and demand constraints",
        "scenario_status": "decision-screening sensitivity, not observed dispatch",
    }, indent=2), encoding="utf-8")
    draw_architecture()
    figure_graph_benchmark()
    figure_pareto(plants, tpp_network, distances, baseline)
    figure_scenarios(plants, tpp_network, distances)
    print(f"Saved figures to {OUT}")
    print(f"Baseline scenario allocated {flow:.3f} Mt across {len(links)} positive links")


if __name__ == "__main__":
    main()
