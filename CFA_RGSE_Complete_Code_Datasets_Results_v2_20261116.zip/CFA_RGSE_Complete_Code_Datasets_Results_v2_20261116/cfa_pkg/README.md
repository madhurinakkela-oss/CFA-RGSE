# Cement--Fly-Ash Real-Data Modelling Project

This project joins four India-focused datasets, audits their quality, trains a
new multi-view model, evaluates it with state-held-out cross-validation, runs
ablations and baselines, estimates missing values, and produces a transparent
cement--fly-ash linkage priority index.

## Source datasets

| File | Rows | Role | Source status |
|---|---:|---|---|
| `CEA_Statewise_Fly_Ash_2024_25.csv` | 18 | State fly-ash generation/utilisation (17 states + India total) | CEA Table 4.1 |
| `CEA_Thermal_Power_Plants_2024_25.csv` | 189 | TPP location, capacity and pithead class | CEA Annexure 1 |
| `Cement_Plants_in_India_2024.csv` | 380 | Cement-plant location, capacity and production fields | Esri India Living Atlas layer |
| `CEA_Major_Cement_Plants_2025.csv` | 141 | Indicative major-plant names and locations | CEA Annexure 2, as of 20 October 2025 |

Official/reference pages:

- CEA 2024-25 ash report: <https://cea.nic.in/notification/ash-generation-and-utilization-at-coal-liginite-based-grid-connected-thermal-power-stations-for-the-year-2024-25/?lang=en>
- Esri India cement layer: <https://livingatlas.esri.in/server/rest/services/Cement_Plants_in_India_2024/MapServer/0>

The CEA files are Indian government data. The cement-plant geometry layer is
India-specific but published by Esri India; it must not be described as a
Government of India dataset.

## Audited data

- 380 cement plants; 272 valid capacity labels and 108 missing capacity values.
- 115 positive production labels; 265 missing/invalid production values.
- Two negative production source values are treated as missing sentinels.
- 341 cement rows receive a state fly-ash join; 39 do not.
- One invalid TPP coordinate is excluded from distance features.
- Four zero-capacity TPP rows are retained and flagged by their source values.
- 24 conservative, high-confidence matches to the indicative CEA major-plant list.

`data/processed/cement_flyash_model_dataset.csv` contains the analysis-ready
plant table. `data/processed/data_quality_report.json` records the complete
audit.

## Proposed model: CFA-RGSE

**CFA-RGSE** means **Cement--Fly-Ash Reliability-Gated Spatial Ensemble**.
It fits separate Extra-Trees views for:

1. plant geometry/geography;
2. state fly-ash context;
3. TPP proximity and nearby capacity; and
4. high-confidence CEA major-plant matching.

Predictions are blended with observation-specific reliability weights derived
from inner state-grouped cross-validation error and tree disagreement. Gate
sharpness is selected only from inner out-of-fold predictions. Targets are
modelled on a `log1p` scale, then converted back to source units.

The primary task estimates missing installed capacity. The production task is
secondary and exploratory because only 115 positive labels are available.

## Evaluation design

- Five-fold `GroupKFold`, with state as the group: every test plant belongs to
  a state not used for training in that outer fold.
- Standard baselines: median, ridge, random forest, extra trees, gradient
  boosting and MLP.
- Ablations: no reliability gate, no fly-ash view, no TPP view, no CEA-major
  view, and a tested spatial residual correction.
- State-cluster bootstrap with 5,000 resamples and a state-level Wilcoxon test
  compare CFA-RGSE with Random Forest.

## Actual results

The values below are means across the five held-out-state folds.

| Task/model | MAE | RMSE | R2 |
|---|---:|---:|---:|
| Capacity: CFA-RGSE | 0.911 | 1.303 | 0.361 |
| Capacity: Random Forest | 0.921 | 1.320 | 0.345 |
| Production: CFA-RGSE | 0.517 | 0.749 | 0.468 |
| Production: Random Forest | 0.538 | 0.788 | 0.412 |

Capacity pooled RMSE is 1.318 for CFA-RGSE versus 1.336 for Random Forest. The
state-cluster bootstrap 95% interval for the paired RMSE difference is
[-0.049, 0.022], so this improvement is **not statistically decisive**.

Production pooled RMSE is 0.759 versus 0.797. Its bootstrap interval for the
paired difference is [-0.073, -0.001], but this task remains exploratory due
to the small, sparse label set; the state-level Wilcoxon MAE p-value is 0.066.

The capacity ablation without the state fly-ash view is marginally better
(RMSE 1.298) than the full model (1.303). Therefore this project does not claim
that state-level fly-ash aggregates improve capacity prediction. Instead, the
fly-ash data is used directly in the downstream linkage-priority index. The
tested spatial residual correction also degraded both tasks and is retained as
a negative ablation result.

## Decision-support linkage index

`results/cement_flyash_linkage_priority.csv` contains an analyst-defined score
for 341 plants with state fly-ash coverage:

`100 x (0.35 capacity percentile + 0.30 state unutilised fly-ash percentile +
0.20 TPP capacity within 100 km percentile + 0.15 inverse nearest-TPP-distance
percentile)`.

This score is a screening tool, not a learned ground-truth outcome. Capacity is
explicitly marked as observed or model-estimated, and rows without state
fly-ash data are not scored rather than being assigned zero.

## Run locally or in Colab

Run the complete pipeline from the project root:

```bash
python scripts/run_all.py
```

Or open `notebooks/CFA_RGSE_Real_Experiment_Colab.ipynb`, upload the packaged
ZIP when prompted, and run all cells. All random seeds are fixed at 42.

## Important limitations

- State fly-ash values are aggregates in lakh metric tonnes (LMT), not
  plant-level TPP ash measurements.
- The CEA major-plant list is indicative and inexhaustive; an unmatched row is
  not evidence that a plant is non-major.
- Model spread columns are ensemble disagreement measures, not calibrated
  confidence intervals.
- Production values and capacity fields retain the source layer's semantics;
  they should be independently validated before investment, logistics or
  policy decisions.
- These observational data support prediction and prioritisation, not causal
  claims about fly ash causing cement capacity or output.

