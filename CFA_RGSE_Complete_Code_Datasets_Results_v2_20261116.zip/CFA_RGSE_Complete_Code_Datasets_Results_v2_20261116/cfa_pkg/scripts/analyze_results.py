#!/usr/bin/env python3
"""Create statistical comparisons and publication-ready result plots."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


PROPOSED = "CFA-RGSE (full)"
BASELINE = "RandomForest"
BASELINE_MODELS = [
    "Median",
    "Ridge",
    "RandomForest",
    "ExtraTrees",
    "GradientBoosting",
    "MLP",
    PROPOSED,
]


def pooled_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    return {
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "rmse": float(math.sqrt(mean_squared_error(y_true, y_pred))),
        "r2": float(r2_score(y_true, y_pred)),
    }


def paired_cluster_bootstrap(
    oof: pd.DataFrame,
    proposed: str = PROPOSED,
    baseline: str = BASELINE,
    iterations: int = 5000,
    seed: int = 42,
) -> dict:
    pivot = oof.loc[oof["model"].isin([proposed, baseline])].pivot(
        index=["objectid", "state_canonical", "y_true"], columns="model", values="y_pred"
    ).dropna()
    frame = pivot.reset_index()
    states = frame["state_canonical"].unique()
    rng = np.random.default_rng(seed)
    cluster_rows = []
    for state in states:
        cluster = frame.loc[frame["state_canonical"].eq(state)]
        y = cluster["y_true"].to_numpy(float)
        p = cluster[proposed].to_numpy(float)
        b = cluster[baseline].to_numpy(float)
        cluster_rows.append(
            [
                len(cluster),
                np.square(y - p).sum(),
                np.square(y - b).sum(),
                np.abs(y - p).sum(),
                np.abs(y - b).sum(),
            ]
        )
    cluster_stats = np.asarray(cluster_rows, dtype=float)
    draws = rng.integers(0, len(states), size=(iterations, len(states)))
    sampled = cluster_stats[draws].sum(axis=1)
    sample_count = sampled[:, 0]
    rmse_diffs = np.sqrt(sampled[:, 1] / sample_count) - np.sqrt(
        sampled[:, 2] / sample_count
    )
    mae_diffs = sampled[:, 3] / sample_count - sampled[:, 4] / sample_count

    state_errors = (
        oof.loc[oof["model"].isin([proposed, baseline])]
        .assign(abs_error=lambda x: np.abs(x["y_true"] - x["y_pred"]))
        .groupby(["state_canonical", "model"])["abs_error"]
        .mean()
        .unstack()
        .dropna()
    )
    statistic, p_value = wilcoxon(
        state_errors[proposed], state_errors[baseline], alternative="two-sided"
    )

    proposed_rows = oof.loc[oof["model"].eq(proposed)]
    baseline_rows = oof.loc[oof["model"].eq(baseline)]
    result = {
        "comparison": f"{proposed} minus {baseline}",
        "n_plants": int(len(frame)),
        "n_state_clusters": int(len(states)),
        "proposed_pooled": pooled_metrics(
            proposed_rows["y_true"].to_numpy(float), proposed_rows["y_pred"].to_numpy(float)
        ),
        "baseline_pooled": pooled_metrics(
            baseline_rows["y_true"].to_numpy(float), baseline_rows["y_pred"].to_numpy(float)
        ),
        "rmse_difference": float(np.mean(rmse_diffs)),
        "rmse_difference_ci95": [
            float(np.quantile(rmse_diffs, 0.025)),
            float(np.quantile(rmse_diffs, 0.975)),
        ],
        "probability_proposed_lower_rmse": float(np.mean(rmse_diffs < 0)),
        "mae_difference": float(np.mean(mae_diffs)),
        "mae_difference_ci95": [
            float(np.quantile(mae_diffs, 0.025)),
            float(np.quantile(mae_diffs, 0.975)),
        ],
        "probability_proposed_lower_mae": float(np.mean(mae_diffs < 0)),
        "wilcoxon_state_mae_statistic": float(statistic),
        "wilcoxon_state_mae_two_sided_p": float(p_value),
        "inference_note": "Cluster bootstrap resamples states. The Wilcoxon test uses per-state MAE.",
    }
    return result


def bar_plot(summary: pd.DataFrame, models: list[str], title: str, output: Path) -> None:
    plot = summary.loc[summary["model"].isin(models)].copy().sort_values("rmse_mean")
    colors = ["#9CA3AF" if name != PROPOSED else "#0F766E" for name in plot["model"]]
    fig, ax = plt.subplots(figsize=(8.6, 4.8))
    ax.barh(
        plot["model"],
        plot["rmse_mean"],
        xerr=plot["rmse_std"],
        color=colors,
        edgecolor="white",
        capsize=3,
    )
    ax.invert_yaxis()
    ax.set_xlabel("RMSE (mean ± SD across state-held-out folds)")
    ax.set_title(title, loc="left", fontweight="bold")
    ax.grid(axis="x", alpha=0.25)
    ax.spines[["top", "right", "left"]].set_visible(False)
    for index, value in enumerate(plot["rmse_mean"]):
        ax.text(value + 0.01, index, f"{value:.3f}", va="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(output, dpi=300, bbox_inches="tight")
    plt.close(fig)


def ablation_plot(summary: pd.DataFrame, title: str, output: Path) -> None:
    mask = (
        summary["model"].eq(PROPOSED)
        | summary["model"].str.startswith("w/o")
        | summary["model"].str.startswith("with")
    )
    plot = summary.loc[mask].copy().sort_values("rmse_mean")
    colors = ["#0F766E" if name == PROPOSED else "#D1D5DB" for name in plot["model"]]
    fig, ax = plt.subplots(figsize=(8.8, 4.5))
    ax.barh(plot["model"], plot["rmse_mean"], color=colors, edgecolor="white")
    ax.invert_yaxis()
    ax.set_xlabel("RMSE (lower is better)")
    ax.set_title(title, loc="left", fontweight="bold")
    ax.grid(axis="x", alpha=0.25)
    ax.spines[["top", "right", "left"]].set_visible(False)
    for index, value in enumerate(plot["rmse_mean"]):
        ax.text(value + 0.004, index, f"{value:.3f}", va="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(output, dpi=300, bbox_inches="tight")
    plt.close(fig)


def scatter_plot(oof: pd.DataFrame, title: str, unit: str, output: Path) -> None:
    plot = oof.loc[oof["model"].eq(PROPOSED)].copy()
    metrics = pooled_metrics(plot["y_true"].to_numpy(), plot["y_pred"].to_numpy())
    low = min(plot["y_true"].min(), plot["y_pred"].min())
    high = max(plot["y_true"].max(), plot["y_pred"].max())
    fig, ax = plt.subplots(figsize=(6.0, 5.4))
    points = ax.scatter(
        plot["y_true"],
        plot["y_pred"],
        c=plot["fold"],
        cmap="viridis",
        s=34,
        alpha=0.78,
        edgecolors="white",
        linewidths=0.4,
    )
    ax.plot([low, high], [low, high], linestyle="--", color="#374151", linewidth=1.2)
    ax.set_xlabel(f"Observed {unit}")
    ax.set_ylabel(f"Out-of-fold predicted {unit}")
    ax.set_title(title, loc="left", fontweight="bold")
    ax.text(
        0.03,
        0.96,
        f"Pooled RMSE = {metrics['rmse']:.3f}\nPooled $R^2$ = {metrics['r2']:.3f}",
        transform=ax.transAxes,
        va="top",
        bbox={"boxstyle": "round,pad=0.35", "facecolor": "white", "alpha": 0.88, "edgecolor": "#D1D5DB"},
    )
    fig.colorbar(points, ax=ax, label="State-held-out fold")
    ax.grid(alpha=0.20)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(output, dpi=300, bbox_inches="tight")
    plt.close(fig)


def prediction_map(dataset: pd.DataFrame, predictions: pd.DataFrame, output: Path) -> None:
    merged = dataset.merge(
        predictions[["objectid", "predicted_capacity_mtpa"]], on="objectid", how="left"
    )
    merged["capacity_display"] = merged["capacity_mtpa_target"].fillna(
        merged["predicted_capacity_mtpa"]
    )
    fig, ax = plt.subplots(figsize=(7.8, 6.8))
    observed = merged[merged["capacity_label_available"].eq(1)]
    missing = merged[merged["capacity_label_available"].eq(0)]
    ax.scatter(
        observed["centroid_longitude"],
        observed["centroid_latitude"],
        c=observed["capacity_display"],
        cmap="plasma",
        s=18,
        alpha=0.45,
        marker="o",
        label="Observed capacity",
    )
    points = ax.scatter(
        missing["centroid_longitude"],
        missing["centroid_latitude"],
        c=missing["capacity_display"],
        cmap="plasma",
        s=42,
        edgecolors="black",
        linewidths=0.35,
        marker="^",
        label="Model estimate",
    )
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title("Cement-plant capacity coverage and model estimates", loc="left", fontweight="bold")
    ax.legend(frameon=False, loc="lower left")
    fig.colorbar(points, ax=ax, label="Capacity (MTPA)")
    ax.grid(alpha=0.15)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(output, dpi=300, bbox_inches="tight")
    plt.close(fig)


def analyze_task(results_dir: Path, plots_dir: Path, task: str, unit: str) -> dict:
    summary = pd.read_csv(results_dir / f"{task}_group_cv_summary.csv")
    oof = pd.read_csv(results_dir / f"{task}_group_cv_oof_predictions.csv")
    stats = paired_cluster_bootstrap(oof)
    with (results_dir / f"{task}_paired_statistics.json").open("w", encoding="utf-8") as handle:
        json.dump(stats, handle, indent=2)

    bar_plot(summary, BASELINE_MODELS, f"{task.title()} prediction: baseline comparison", plots_dir / f"{task}_baseline_comparison.png")
    ablation_plot(summary, f"{task.title()} prediction: CFA-RGSE ablations", plots_dir / f"{task}_ablation.png")
    scatter_plot(oof, f"{task.title()} prediction: observed vs out-of-fold estimates", unit, plots_dir / f"{task}_actual_vs_predicted.png")
    return stats


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, default=Path("data/processed/cement_flyash_model_dataset.csv"))
    parser.add_argument("--results-dir", type=Path, default=Path("results"))
    parser.add_argument("--plots-dir", type=Path, default=Path("results/plots"))
    args = parser.parse_args()
    args.plots_dir.mkdir(parents=True, exist_ok=True)

    capacity_stats = analyze_task(args.results_dir, args.plots_dir, "capacity", "capacity (MTPA)")
    production_stats = analyze_task(args.results_dir, args.plots_dir, "production", "production (Mt)")
    dataset = pd.read_csv(args.dataset)
    capacity_predictions = pd.read_csv(args.results_dir / "capacity_missing_predictions.csv")
    prediction_map(dataset, capacity_predictions, args.plots_dir / "capacity_prediction_map.png")

    print(json.dumps({"capacity": capacity_stats, "production": production_stats}, indent=2))


if __name__ == "__main__":
    main()
