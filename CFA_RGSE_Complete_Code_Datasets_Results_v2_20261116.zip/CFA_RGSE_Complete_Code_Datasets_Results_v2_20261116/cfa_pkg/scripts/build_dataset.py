#!/usr/bin/env python3
"""Build the modelling table from four India cement/fly-ash source files.

The script preserves the source columns, adds audited joins, and engineers
geospatial supply-context features. It does not impute the two modelling
targets (installed capacity and production).
"""

from __future__ import annotations

import argparse
import json
import re
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path

import numpy as np
import pandas as pd


SOURCE_URLS = {
    "fly_ash_report": "https://cea.nic.in/notification/ash-generation-and-utilization-at-coal-liginite-based-grid-connected-thermal-power-stations-for-the-year-2024-25/?lang=en",
    "cement_layer": "https://livingatlas.esri.in/server/rest/services/Cement_Plants_in_India_2024/MapServer/0",
}

STATE_ALIASES = {
    "mp": "Madhya Pradesh",
    "madhya pradesh": "Madhya Pradesh",
    "up": "Uttar Pradesh",
    "uttar pradesh": "Uttar Pradesh",
    "west bangal": "West Bengal",
    "west bengal": "West Bengal",
    "jammu and kashmir": "Jammu And Kashmir",
    "jammu & kashmir": "Jammu And Kashmir",
    "orissa": "Odisha",
    "pondicherry": "Puducherry",
    "tamilnadu": "Tamil Nadu",
    "maharastra": "Maharashtra",
}

NAME_STOPWORDS = {
    "cement",
    "cements",
    "limited",
    "ltd",
    "private",
    "pvt",
    "plant",
    "unit",
    "works",
    "company",
    "corporation",
    "india",
    "industries",
    "industry",
    "factory",
    "the",
    "and",
    "of",
    "at",
    "distt",
    "district",
}


def canonical_state(value: object) -> str:
    text = str(value).strip()
    key = re.sub(r"\s+", " ", text.lower())
    return STATE_ALIASES.get(key, text)


def normalize_text(value: object, drop_stopwords: bool = False) -> str:
    text = unicodedata.normalize("NFKD", str(value)).encode("ascii", "ignore").decode()
    tokens = re.findall(r"[a-z0-9]+", text.lower())
    if drop_stopwords:
        tokens = [token for token in tokens if token not in NAME_STOPWORDS]
    return " ".join(tokens)


def infer_state(location: object, known_states: list[str]) -> str | None:
    text = normalize_text(location)
    compact_text = text.replace(" ", "")
    aliases = sorted(
        set(known_states)
        | {"MP", "UP", "West Bangal", "Jammu & Kashmir", "Orissa", "Pondicherry"},
        key=len,
        reverse=True,
    )
    for state in aliases:
        normalized = normalize_text(state)
        if normalized in text or normalized.replace(" ", "") in compact_text:
            return canonical_state(state)
    return None


def token_dice(left: str, right: str) -> float:
    a, b = set(left.split()), set(right.split())
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return 2.0 * len(a & b) / (len(a) + len(b))


def match_score(left: str, right: str) -> float:
    sequence = SequenceMatcher(None, left, right).ratio()
    dice = token_dice(left, right)
    containment = 1.0 if left and right and (left in right or right in left) else 0.0
    return max(sequence, dice, 0.90 * containment)


def haversine_matrix_km(lat1: np.ndarray, lon1: np.ndarray, lat2: np.ndarray, lon2: np.ndarray) -> np.ndarray:
    """Return pairwise great-circle distances in kilometres."""
    r = 6371.0088
    lat1r = np.radians(lat1)[:, None]
    lon1r = np.radians(lon1)[:, None]
    lat2r = np.radians(lat2)[None, :]
    lon2r = np.radians(lon2)[None, :]
    dlat = lat2r - lat1r
    dlon = lon2r - lon1r
    a = np.sin(dlat / 2.0) ** 2 + np.cos(lat1r) * np.cos(lat2r) * np.sin(dlon / 2.0) ** 2
    return 2.0 * r * np.arcsin(np.sqrt(np.clip(a, 0.0, 1.0)))


def add_tpp_features(cement: pd.DataFrame, tpp: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    out = cement.copy()
    valid_geo = tpp["latitude"].between(6.0, 38.0) & tpp["longitude"].between(68.0, 98.0)
    valid_tpp = tpp.loc[valid_geo].copy().reset_index(drop=True)
    invalid_tpp = tpp.loc[~valid_geo].copy()

    dist = haversine_matrix_km(
        out["centroid_latitude"].to_numpy(float),
        out["centroid_longitude"].to_numpy(float),
        valid_tpp["latitude"].to_numpy(float),
        valid_tpp["longitude"].to_numpy(float),
    )
    nearest_index = dist.argmin(axis=1)
    nearest = valid_tpp.iloc[nearest_index].reset_index(drop=True)
    out["nearest_tpp_distance_km"] = dist[np.arange(len(out)), nearest_index]
    out["nearest_tpp_capacity_mw"] = nearest["capacity_mw"].to_numpy(float)
    out["nearest_tpp_name"] = nearest["tpp_tps_name"].to_numpy()
    out["nearest_tpp_state"] = nearest["state_canonical"].to_numpy()
    out["nearest_tpp_same_state"] = (
        out["state_canonical"].to_numpy() == nearest["state_canonical"].to_numpy()
    ).astype(int)
    out["nearest_tpp_pithead"] = nearest["pithead_class"].to_numpy()

    for radius in (50, 100, 200):
        within = dist <= radius
        out[f"tpp_count_within_{radius}km"] = within.sum(axis=1)
        out[f"tpp_capacity_within_{radius}km_mw"] = within @ valid_tpp["capacity_mw"].to_numpy(float)

    for pit_class, label in (("PH", "pithead"), ("NPH", "nonpithead")):
        mask = valid_tpp["pithead_class"].eq(pit_class).to_numpy()
        if mask.any():
            out[f"nearest_{label}_tpp_distance_km"] = dist[:, mask].min(axis=1)
        else:
            out[f"nearest_{label}_tpp_distance_km"] = np.nan

    return out, invalid_tpp


def add_major_plant_match(cement: pd.DataFrame, major: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    out = cement.copy()
    major = major.copy()
    known_states = sorted(out["state_canonical"].dropna().unique().tolist())
    major["state_canonical"] = major["location"].map(lambda x: infer_state(x, known_states))
    major["company_text"] = major["cement_plant"].map(
        lambda x: normalize_text(x, drop_stopwords=True)
    )
    major["location_text"] = major["location"].map(normalize_text)

    matched_serials: list[float] = []
    matched_names: list[str | None] = []
    scores: list[float] = []
    company_scores: list[float] = []
    location_scores: list[float] = []
    brand_overlaps: list[int] = []
    state_constrained: list[int] = []

    for row in out.itertuples(index=False):
        query_company = normalize_text(row.name, drop_stopwords=True)
        location_tokens = set(
            normalize_text(f"{row.subdistrict} {row.district} {row.state_canonical}").split()
        )
        query_company_tokens = [
            token for token in query_company.split() if token not in location_tokens
        ]
        query_company = " ".join(query_company_tokens) or normalize_text(
            row.name, drop_stopwords=True
        )
        query_location = normalize_text(f"{row.name} {row.subdistrict} {row.district}")
        candidates = major.loc[major["state_canonical"].eq(row.state_canonical)]
        used_state = 1
        if candidates.empty:
            candidates = major
            used_state = 0
        candidate_scores: dict[int, tuple[float, float, float, int]] = {}
        query_brand_tokens = set(query_company.split())
        for idx, candidate in candidates.iterrows():
            company_text = candidate["company_text"]
            company_dice = token_dice(query_company, company_text)
            company_sequence = SequenceMatcher(None, query_company, company_text).ratio()
            company_score = max(company_dice, 0.75 * company_sequence)
            location_score = max(
                token_dice(query_location, candidate["location_text"]),
                SequenceMatcher(None, query_location, candidate["location_text"]).ratio(),
            )
            brand_overlap = int(bool(query_brand_tokens & set(company_text.split())))
            combined = min(1.0, 0.72 * company_score + 0.28 * location_score)
            candidate_scores[idx] = (combined, company_score, location_score, brand_overlap)
        best_idx = max(candidate_scores, key=lambda idx: candidate_scores[idx][0])
        best_combined, best_company, best_location, best_brand_overlap = candidate_scores[best_idx]
        best = major.loc[best_idx]
        matched_serials.append(float(best["serial_no"]))
        matched_names.append(str(best["cement_plant"]))
        scores.append(float(best_combined))
        company_scores.append(float(best_company))
        location_scores.append(float(best_location))
        brand_overlaps.append(int(best_brand_overlap))
        state_constrained.append(used_state)

    out["cea_major_match_serial"] = matched_serials
    out["cea_major_match_name"] = matched_names
    out["cea_major_match_score"] = scores
    out["cea_major_company_score"] = company_scores
    out["cea_major_location_score"] = location_scores
    out["cea_major_brand_token_overlap"] = brand_overlaps
    out["cea_major_match_state_constrained"] = state_constrained
    out["cea_major_match_high_confidence"] = (
        (out["cea_major_match_score"] >= 0.55)
        & (out["cea_major_match_state_constrained"] == 1)
        & ((out["cea_major_brand_token_overlap"] == 1) | (out["cea_major_company_score"] >= 0.70))
        & (out["cea_major_location_score"] >= 0.35)
    ).astype(int)

    audit = out[
        [
            "objectid",
            "name",
            "state_canonical",
            "cea_major_match_serial",
            "cea_major_match_name",
            "cea_major_match_score",
            "cea_major_company_score",
            "cea_major_location_score",
            "cea_major_brand_token_overlap",
            "cea_major_match_state_constrained",
            "cea_major_match_high_confidence",
        ]
    ].sort_values("cea_major_match_score", ascending=False)
    return out, audit


def build(raw_dir: Path, output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)

    cement = pd.read_csv(raw_dir / "Cement_Plants_in_India_2024.csv", encoding="utf-8-sig")
    fly = pd.read_csv(raw_dir / "CEA_Statewise_Fly_Ash_2024_25.csv", encoding="utf-8-sig")
    tpp = pd.read_csv(raw_dir / "CEA_Thermal_Power_Plants_2024_25.csv", encoding="utf-8-sig")
    major = pd.read_csv(raw_dir / "CEA_Major_Cement_Plants_2025.csv", encoding="utf-8-sig")

    cement["state_canonical"] = cement["state"].map(canonical_state)
    fly["state_canonical"] = fly["state"].map(canonical_state)
    tpp["state_canonical"] = tpp["state"].map(canonical_state)

    # Preserve source values and create modelling targets only after validity checks.
    cement["capacity_mtpa_source"] = pd.to_numeric(cement["capacitym"], errors="coerce")
    cement["production_mt_source"] = pd.to_numeric(cement["production"], errors="coerce")
    cement["capacity_mtpa_target"] = cement["capacity_mtpa_source"].where(
        cement["capacity_mtpa_source"] > 0
    )
    cement["production_mt_target"] = cement["production_mt_source"].where(
        cement["production_mt_source"] > 0
    )
    cement["capacity_label_available"] = cement["capacity_mtpa_target"].notna().astype(int)
    cement["production_label_available"] = cement["production_mt_target"].notna().astype(int)
    cement["capacity_t_consistency_ratio"] = cement["capacityt"] / (
        1000.0 * cement["capacity_mtpa_source"]
    )

    fly_state = fly.loc[fly["state_canonical"].ne("Grand Total")].copy()
    fly_state = fly_state.drop(columns=["serial_no", "state", "reporting_year", "source_table"])
    fly_state = fly_state.rename(
        columns={
            "number_of_plants": "state_tpp_count_reported",
            "coal_consumed_lmt": "state_coal_consumed_lmt",
            "ash_generation_lmt": "state_ash_generation_lmt",
            "ash_utilisation_lmt": "state_ash_utilisation_lmt",
            "utilisation_percent": "state_ash_utilisation_percent",
        }
    )
    model = cement.merge(fly_state, on="state_canonical", how="left", validate="many_to_one")
    model["state_flyash_data_available"] = model["state_ash_generation_lmt"].notna().astype(int)

    model, invalid_tpp = add_tpp_features(model, tpp)
    model, match_audit = add_major_plant_match(model, major)

    # Reviewer-facing completeness and provenance fields.
    model["source_cement_layer"] = "Esri India Living Atlas, Cement Plants in India (2024 extract)"
    model["source_flyash_tpp"] = "Central Electricity Authority, Fly Ash Report 2024-25"
    model["source_major_cement"] = "CEA Annexure 2, indicative major cement plants as of 2025-10-20"

    model_path = output_dir / "cement_flyash_model_dataset.csv"
    match_path = output_dir / "major_plant_match_audit.csv"
    invalid_tpp_path = output_dir / "invalid_tpp_coordinates.csv"
    model.to_csv(model_path, index=False)
    match_audit.to_csv(match_path, index=False)
    invalid_tpp.to_csv(invalid_tpp_path, index=False)

    duplicate_major = int(major.duplicated(subset=["cement_plant", "location"], keep=False).sum())
    capacity_ratio = model["capacity_t_consistency_ratio"].dropna()
    report = {
        "source_rows": {
            "cement_plants": int(len(cement)),
            "thermal_power_plants": int(len(tpp)),
            "state_fly_ash_rows_including_grand_total": int(len(fly)),
            "major_cement_plants": int(len(major)),
        },
        "model_rows": int(len(model)),
        "labels": {
            "valid_capacity": int(model["capacity_label_available"].sum()),
            "missing_capacity": int((1 - model["capacity_label_available"]).sum()),
            "valid_production": int(model["production_label_available"].sum()),
            "missing_or_invalid_production": int((1 - model["production_label_available"]).sum()),
            "invalid_negative_production_values": int((cement["production_mt_source"] <= 0).fillna(False).sum()),
        },
        "joins": {
            "cement_rows_with_state_flyash": int(model["state_flyash_data_available"].sum()),
            "cement_rows_without_state_flyash": int((1 - model["state_flyash_data_available"]).sum()),
            "high_confidence_major_plant_matches": int(model["cea_major_match_high_confidence"].sum()),
            "major_source_duplicate_rows_by_name_location": duplicate_major,
        },
        "geospatial_audit": {
            "invalid_tpp_coordinate_rows_excluded_from_distance_features": int(len(invalid_tpp)),
            "zero_capacity_tpp_rows_preserved": int((tpp["capacity_mw"] <= 0).sum()),
            "nearest_tpp_distance_km_min": float(model["nearest_tpp_distance_km"].min()),
            "nearest_tpp_distance_km_median": float(model["nearest_tpp_distance_km"].median()),
            "nearest_tpp_distance_km_max": float(model["nearest_tpp_distance_km"].max()),
        },
        "consistency_checks": {
            "capacityt_to_capacitym_x1000_median_ratio": float(capacity_ratio.median()),
            "capacityt_ratio_outside_0_99_to_1_01": int(((capacity_ratio < 0.99) | (capacity_ratio > 1.01)).sum()),
        },
        "major_match_rule": "same-state candidates; combined>=0.55; location>=0.35; brand overlap or company score>=0.70",
        "source_urls": SOURCE_URLS,
        "limitations": [
            "CEA state fly-ash values are state-level aggregates, not plant-level ash measurements.",
            "The CEA major-cement list is indicative and inexhaustive; unmatched rows are not non-major labels.",
            "Production has sparse coverage and two negative source values; negative values are treated as missing targets.",
            "The Esri capacity and production fields require source-metadata confirmation before causal interpretation.",
        ],
    }
    with (output_dir / "data_quality_report.json").open("w", encoding="utf-8") as handle:
        json.dump(report, handle, indent=2)

    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", type=Path, default=Path("data/raw"))
    parser.add_argument("--output-dir", type=Path, default=Path("data/processed"))
    args = parser.parse_args()
    report = build(args.raw_dir, args.output_dir)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
