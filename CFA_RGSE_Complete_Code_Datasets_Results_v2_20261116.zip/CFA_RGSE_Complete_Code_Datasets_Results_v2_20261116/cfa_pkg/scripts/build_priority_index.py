"""Build a transparent cement--fly-ash linkage priority index.

This is a decision-support index, not a supervised model target.  It combines
cement demand scale with state-level unutilised fly ash and local thermal-power
proximity.  The component weights are explicit so they can be sensitivity
tested or replaced by stakeholder-selected weights.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "processed" / "cement_flyash_model_dataset.csv"
CAPACITY_PREDICTIONS = ROOT / "results" / "capacity_missing_predictions.csv"
OUTPUT = ROOT / "results" / "cement_flyash_linkage_priority.csv"
TOP_OUTPUT = ROOT / "results" / "cement_flyash_linkage_priority_top25.csv"


WEIGHTS = {
    "cement_capacity": 0.35,
    "state_unutilised_flyash": 0.30,
    "tpp_capacity_within_100km": 0.20,
    "tpp_proximity": 0.15,
}


def percentile_component(series: pd.Series, ascending: bool = True) -> pd.Series:
    """Return percentile ranks in [0, 1], preserving missing values."""
    return series.rank(method="average", pct=True, ascending=ascending)


def main() -> None:
    plants = pd.read_csv(DATA)
    predicted = pd.read_csv(CAPACITY_PREDICTIONS)[
        ["objectid", "predicted_capacity_mtpa", "model_spread_mtpa"]
    ]
    plants = plants.merge(predicted, on="objectid", how="left", validate="one_to_one")

    plants["capacity_used_mtpa"] = plants["capacity_mtpa_target"].fillna(
        plants["predicted_capacity_mtpa"]
    )
    plants["capacity_value_type"] = np.where(
        plants["capacity_label_available"].eq(1), "observed", "model_estimated"
    )
    plants["state_unutilised_flyash_lmt"] = (
        plants["state_ash_generation_lmt"] - plants["state_ash_utilisation_lmt"]
    ).clip(lower=0)

    scoreable = plants["state_flyash_data_available"].eq(1)
    plants["component_cement_capacity"] = np.nan
    plants["component_state_unutilised_flyash"] = np.nan
    plants["component_tpp_capacity_100km"] = np.nan
    plants["component_tpp_proximity"] = np.nan

    plants.loc[scoreable, "component_cement_capacity"] = percentile_component(
        plants.loc[scoreable, "capacity_used_mtpa"]
    )
    plants.loc[scoreable, "component_state_unutilised_flyash"] = percentile_component(
        plants.loc[scoreable, "state_unutilised_flyash_lmt"]
    )
    plants.loc[scoreable, "component_tpp_capacity_100km"] = percentile_component(
        plants.loc[scoreable, "tpp_capacity_within_100km_mw"]
    )
    plants.loc[scoreable, "component_tpp_proximity"] = percentile_component(
        plants.loc[scoreable, "nearest_tpp_distance_km"], ascending=False
    )

    plants["linkage_priority_score"] = 100 * (
        WEIGHTS["cement_capacity"] * plants["component_cement_capacity"]
        + WEIGHTS["state_unutilised_flyash"]
        * plants["component_state_unutilised_flyash"]
        + WEIGHTS["tpp_capacity_within_100km"]
        * plants["component_tpp_capacity_100km"]
        + WEIGHTS["tpp_proximity"] * plants["component_tpp_proximity"]
    )
    plants["linkage_priority_rank"] = plants["linkage_priority_score"].rank(
        method="min", ascending=False
    )
    plants["priority_band"] = pd.cut(
        plants["linkage_priority_score"],
        bins=[-np.inf, 40, 60, 75, np.inf],
        labels=["low", "moderate", "high", "very_high"],
    ).astype("string")
    plants.loc[~scoreable, "priority_band"] = "not_scored_no_state_flyash"
    plants["score_confidence"] = np.select(
        [
            ~scoreable,
            plants["capacity_value_type"].eq("observed"),
            plants["capacity_value_type"].eq("model_estimated"),
        ],
        ["not_scored", "higher_observed_capacity", "moderate_estimated_capacity"],
        default="not_scored",
    )
    plants["score_definition"] = (
        "100 x (0.35 capacity percentile + 0.30 state unutilised fly-ash "
        "percentile + 0.20 TPP capacity within 100 km percentile + 0.15 inverse "
        "nearest-TPP-distance percentile); analyst-defined decision index"
    )

    columns = [
        "linkage_priority_rank",
        "linkage_priority_score",
        "priority_band",
        "score_confidence",
        "objectid",
        "uid",
        "name",
        "district",
        "state_canonical",
        "centroid_longitude",
        "centroid_latitude",
        "capacity_used_mtpa",
        "capacity_value_type",
        "model_spread_mtpa",
        "state_ash_generation_lmt",
        "state_ash_utilisation_lmt",
        "state_unutilised_flyash_lmt",
        "nearest_tpp_name",
        "nearest_tpp_distance_km",
        "nearest_tpp_capacity_mw",
        "tpp_capacity_within_100km_mw",
        "component_cement_capacity",
        "component_state_unutilised_flyash",
        "component_tpp_capacity_100km",
        "component_tpp_proximity",
        "score_definition",
    ]
    result = plants[columns].sort_values(
        ["linkage_priority_rank", "state_canonical", "name"], na_position="last"
    )
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(OUTPUT, index=False)
    result.loc[result["linkage_priority_score"].notna()].head(25).to_csv(
        TOP_OUTPUT, index=False
    )

    print(f"Saved {len(result)} plant rows to {OUTPUT}")
    print(f"Scored rows: {result['linkage_priority_score'].notna().sum()}")
    print("\nTop 10 linkage-priority plants:")
    print(
        result.loc[result["linkage_priority_score"].notna(), [
            "linkage_priority_rank",
            "name",
            "state_canonical",
            "linkage_priority_score",
            "capacity_value_type",
        ]]
        .head(10)
        .to_string(index=False)
    )


if __name__ == "__main__":
    main()
