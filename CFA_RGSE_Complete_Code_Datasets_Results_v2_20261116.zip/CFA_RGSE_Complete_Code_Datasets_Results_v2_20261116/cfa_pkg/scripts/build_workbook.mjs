import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = process.argv[2];
const outputDir = process.argv[3];
if (!root || !outputDir) {
  throw new Error("Usage: build_workbook.mjs PROJECT_ROOT OUTPUT_DIR");
}

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(path.join(outputDir, "workbook_previews"), { recursive: true });

function parseCsv(text) {
  text = text.replace(/^\uFEFF/, "");
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    if (quoted) {
      if (char === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        field += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(field);
      field = "";
    } else if (char === "\n") {
      row.push(field.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      field = "";
    } else {
      field += char;
    }
  }
  if (field.length || row.length) {
    row.push(field.replace(/\r$/, ""));
    rows.push(row);
  }
  return rows.filter((r) => !(r.length === 1 && r[0] === ""));
}

function toCell(value) {
  const trimmed = String(value ?? "").trim();
  if (trimmed === "") return null;
  if (/^-?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(trimmed)) {
    const numeric = Number(trimmed);
    if (Number.isFinite(numeric)) return numeric;
  }
  return trimmed.startsWith("=") ? `'${trimmed}` : trimmed;
}

async function readCsv(relativePath) {
  const text = await fs.readFile(path.join(root, relativePath), "utf8");
  return parseCsv(text).map((row) => row.map(toCell));
}

async function readJson(relativePath) {
  return JSON.parse(await fs.readFile(path.join(root, relativePath), "utf8"));
}

function colName(index) {
  let n = index + 1;
  let result = "";
  while (n > 0) {
    n -= 1;
    result = String.fromCharCode(65 + (n % 26)) + result;
    n = Math.floor(n / 26);
  }
  return result;
}

function findRow(rows, model) {
  const headers = rows[0];
  const modelIndex = headers.indexOf("model");
  const values = rows.slice(1).find((row) => row[modelIndex] === model);
  if (!values) throw new Error(`Missing model row: ${model}`);
  return Object.fromEntries(headers.map((h, i) => [h, values[i]]));
}

const quality = await readJson("data/processed/data_quality_report.json");
const capStats = await readJson("results/capacity_paired_statistics.json");
const prodStats = await readJson("results/production_paired_statistics.json");
const capSummary = await readCsv("results/capacity_group_cv_summary.csv");
const prodSummary = await readCsv("results/production_group_cv_summary.csv");
const capAblation = await readCsv("results/capacity_ablation_summary.csv");
const prodAblation = await readCsv("results/production_ablation_summary.csv");
const capMissing = await readCsv("results/capacity_missing_predictions.csv");
const prodMissing = await readCsv("results/production_missing_predictions.csv");
const priority = await readCsv("results/cement_flyash_linkage_priority.csv");
const modelData = await readCsv("data/processed/cement_flyash_model_dataset.csv");
const matchAudit = await readCsv("data/processed/major_plant_match_audit.csv");

const capFull = findRow(capSummary, "CFA-RGSE (full)");
const capRF = findRow(capSummary, "RandomForest");
const capNoFly = findRow(capSummary, "w/o fly-ash view");
const prodFull = findRow(prodSummary, "CFA-RGSE (full)");
const prodRF = findRow(prodSummary, "RandomForest");
const prodNoTpp = findRow(prodSummary, "w/o TPP proximity view");

const workbook = Workbook.create();
const fontFamily = "Arial";
const teal = "#0F766E";
const navy = "#164E63";
const paleTeal = "#CCFBF1";
const paleBlue = "#E0F2FE";
const paleAmber = "#FEF3C7";
const lightGray = "#F3F4F6";
const border = "#D1D5DB";

function titleStyle(range, fill = navy) {
  range.format = {
    fill,
    font: { name: fontFamily, bold: true, color: "#FFFFFF", size: 16 },
    verticalAlignment: "center",
  };
  range.format.rowHeight = 30;
}

function sectionStyle(range, fill = teal) {
  range.format = {
    fill,
    font: { name: fontFamily, bold: true, color: "#FFFFFF", size: 11 },
    verticalAlignment: "center",
  };
}

function dataSheet(name, rows, options = {}) {
  const sheet = workbook.worksheets.add(name);
  sheet.showGridLines = false;
  sheet.tabColor = options.tabColor || teal;
  const headers = rows[0];
  const lastCol = colName(headers.length - 1);
  const lastRow = rows.length + 2;
  sheet.mergeCells("A1:H1");
  sheet.getRange("A1").values = [[options.title || name]];
  titleStyle(sheet.getRange("A1:H1"), options.titleFill || navy);
  sheet.getRange("A2:H2").merge();
  sheet.getRange("A2").values = [[options.subtitle || ""]];
  sheet.getRange("A2:H2").format = {
    fill: paleBlue,
    font: { name: fontFamily, color: "#334155", italic: true, size: 9 },
    wrapText: true,
  };
  sheet.getRange(`A3:${lastCol}${lastRow}`).values = rows;
  sheet.getRange(`A3:${lastCol}${lastRow}`).format.font = { name: fontFamily, size: 9 };
  sheet.getRange(`A3:${lastCol}3`).format = {
    fill: teal,
    font: { name: fontFamily, bold: true, color: "#FFFFFF", size: 9 },
    wrapText: true,
    verticalAlignment: "center",
    borders: { preset: "all", style: "thin", color: border },
  };
  sheet.getRange(`A4:${lastCol}${lastRow}`).format.borders = {
    preset: "all",
    style: "thin",
    color: "#E5E7EB",
  };
  sheet.getRange(`A4:${lastCol}${lastRow}`).format.verticalAlignment = "center";
  sheet.getRange(`A3:${lastCol}${lastRow}`).format.autofitColumns();
  sheet.getRange(`A3:${lastCol}${lastRow}`).format.autofitRows();
  sheet.getRange(`A3:${lastCol}3`).format.rowHeight = 34;
  sheet.freezePanes.freezeRows(3);
  sheet.freezePanes.freezeColumns(Math.min(options.freezeColumns || 2, headers.length));

  headers.forEach((header, index) => {
    const letter = colName(index);
    const key = String(header).toLowerCase();
    let width = 14;
    if (key === "name" || key.includes("plant") || key.includes("held_out_states")) width = 38;
    if (key.includes("state") || key.includes("district")) width = Math.max(width, 19);
    if (key.includes("status") || key.includes("definition") || key.includes("source")) width = 48;
    if (key.includes("url")) width = 55;
    if (key.includes("longitude") || key.includes("latitude")) width = 16;
    sheet.getRange(`${letter}3:${letter}${lastRow}`).format.columnWidth = width;
    if (
      key.includes("rmse") || key.includes("mae") || key.includes("r2") ||
      key.includes("score") || key.includes("weight") || key.includes("spread") ||
      key.includes("capacity") || key.includes("production") || key.includes("distance") ||
      key.includes("generation") || key.includes("utilisation") || key.includes("coal_consumed")
    ) {
      sheet.getRange(`${letter}4:${letter}${lastRow}`).format.numberFormat = "0.000";
    }
    if (key.includes("percent") || key.includes("mape")) {
      sheet.getRange(`${letter}4:${letter}${lastRow}`).format.numberFormat = "0.00";
    }
    if (key === "linkage_priority_rank" || key === "folds" || key === "fold") {
      sheet.getRange(`${letter}4:${letter}${lastRow}`).format.numberFormat = "0";
    }
  });

  const table = sheet.tables.add(`A3:${lastCol}${lastRow}`, true, options.tableName);
  table.showBandedColumns = false;
  table.showFilterButton = true;
  if (options.colorScaleHeader) {
    const index = headers.indexOf(options.colorScaleHeader);
    if (index >= 0) {
      const letter = colName(index);
      sheet.getRange(`${letter}4:${letter}${lastRow}`).conditionalFormats.add("colorScale", {
        colors: ["#FEE2E2", "#FEF3C7", "#DCFCE7"],
        thresholds: ["min", { type: "percentile", value: 50 }, "max"],
      });
    }
  }
  return { sheet, lastRow, lastCol };
}

const summary = workbook.worksheets.add("Summary");
summary.showGridLines = false;
summary.tabColor = teal;
summary.mergeCells("A1:F1");
summary.getRange("A1").values = [["Cement--Fly-Ash Real-Data Research Results"]];
titleStyle(summary.getRange("A1:F1"));
summary.mergeCells("A2:F2");
summary.getRange("A2").values = [[
  "Four India-focused datasets | CFA-RGSE | 5-fold state-held-out validation | actual results",
]];
summary.getRange("A2:F2").format = {
  fill: paleBlue,
  font: { name: fontFamily, italic: true, color: "#334155", size: 10 },
};

summary.getRange("A4:F4").merge();
summary.getRange("A4").values = [["Data audit"]];
sectionStyle(summary.getRange("A4:F4"));
summary.getRange("A5:C11").values = [
  ["Metric", "Value", "Interpretation"],
  ["Cement-plant rows", quality.model_rows, "Full Esri India layer extract used"],
  ["Valid capacity labels", quality.labels.valid_capacity, "Primary supervised target rows"],
  ["Missing capacity", quality.labels.missing_capacity, "CFA-RGSE estimates generated"],
  ["Positive production labels", quality.labels.valid_production, "Secondary exploratory task"],
  ["Rows with state fly-ash join", quality.joins.cement_rows_with_state_flyash, "State aggregates; not plant-level ash"],
  ["High-confidence CEA-major matches", quality.joins.high_confidence_major_plant_matches, "Conservative same-state fuzzy rule"],
];

summary.getRange("A13:F13").merge();
summary.getRange("A13").values = [["Primary task: installed-capacity prediction (MTPA)"]];
sectionStyle(summary.getRange("A13:F13"));
summary.getRange("A14:C22").values = [
  ["Metric", "Value", "Meaning"],
  ["CFA-RGSE fold-mean RMSE", capFull.rmse_mean, "Lower is better"],
  ["Random Forest fold-mean RMSE", capRF.rmse_mean, "Strong standard baseline"],
  ["Absolute RMSE reduction", null, "Random Forest minus CFA-RGSE"],
  ["Relative RMSE reduction", null, "Reduction divided by Random Forest"],
  ["Bootstrap paired RMSE difference", capStats.rmse_difference, "CFA-RGSE minus Random Forest"],
  ["95% CI: lower", capStats.rmse_difference_ci95[0], "State-cluster bootstrap"],
  ["95% CI: upper", capStats.rmse_difference_ci95[1], "Crosses zero"],
  ["Conclusion", "Not statistically decisive", "Report as a modest predictive improvement"],
];
summary.getRange("B17").formulas = [["=B16-B15"]];
summary.getRange("B18").formulas = [["=100*B17/B16"]];
summary.getRange("B18").format.numberFormat = "0.00";

summary.getRange("A24:F24").merge();
summary.getRange("A24").values = [["Secondary task: exploratory production prediction (source million-tonne units)"]];
sectionStyle(summary.getRange("A24:F24"));
summary.getRange("A25:C33").values = [
  ["Metric", "Value", "Meaning"],
  ["CFA-RGSE fold-mean RMSE", prodFull.rmse_mean, "115 positive labels"],
  ["Random Forest fold-mean RMSE", prodRF.rmse_mean, "Strong standard baseline"],
  ["Absolute RMSE reduction", null, "Random Forest minus CFA-RGSE"],
  ["Relative RMSE reduction", null, "Reduction divided by Random Forest"],
  ["Bootstrap paired RMSE difference", prodStats.rmse_difference, "CFA-RGSE minus Random Forest"],
  ["95% CI: lower", prodStats.rmse_difference_ci95[0], "State-cluster bootstrap"],
  ["95% CI: upper", prodStats.rmse_difference_ci95[1], "Slightly below zero"],
  ["Conclusion", "Tentative advantage", "Exploratory because labels are sparse"],
];
summary.getRange("B28").formulas = [["=B27-B26"]];
summary.getRange("B29").formulas = [["=100*B28/B27"]];
summary.getRange("B29").format.numberFormat = "0.00";

summary.getRange("A35:F35").merge();
summary.getRange("A35").values = [["Ablation findings and honest interpretation"]];
sectionStyle(summary.getRange("A35:F35"));
summary.getRange("A36:C41").values = [
  ["Finding", "RMSE", "Interpretation"],
  ["Capacity: without fly-ash view", capNoFly.rmse_mean, "Marginally better than full model"],
  ["Capacity: full CFA-RGSE", capFull.rmse_mean, "Do not claim fly ash improves capacity prediction"],
  ["Production: without TPP view", prodNoTpp.rmse_mean, "Marginally better than full model"],
  ["Production: full CFA-RGSE", prodFull.rmse_mean, "TPP proximity proxy may not match production"],
  ["Spatial residual correction", "Rejected extension", "Degraded both tasks; retained as negative ablation"],
];

summary.getRange("A43:F43").merge();
summary.getRange("A43").values = [["Top linkage-priority examples (decision index, not a ground-truth target)"]];
sectionStyle(summary.getRange("A43:F43"));
const priorityHeaders = priority[0];
const pName = priorityHeaders.indexOf("name");
const pState = priorityHeaders.indexOf("state_canonical");
const pScore = priorityHeaders.indexOf("linkage_priority_score");
const pType = priorityHeaders.indexOf("capacity_value_type");
summary.getRange("A44:D49").values = [
  ["Plant", "State", "Score", "Capacity basis"],
  ...priority.slice(1, 6).map((row) => [row[pName], row[pState], row[pScore], row[pType]]),
];

for (const headerRange of ["A5:C5", "A14:C14", "A25:C25", "A36:C36", "A44:D44"]) {
  summary.getRange(headerRange).format = {
    fill: lightGray,
    font: { name: fontFamily, bold: true, color: "#111827", size: 10 },
    borders: { preset: "all", style: "thin", color: border },
  };
}
for (const bodyRange of ["A6:C11", "A15:C22", "A26:C33", "A37:C41", "A45:D49"]) {
  summary.getRange(bodyRange).format = {
    font: { name: fontFamily, size: 9 },
    borders: { preset: "all", style: "thin", color: "#E5E7EB" },
    verticalAlignment: "center",
    wrapText: true,
  };
}
summary.getRange("B15:B21").format.numberFormat = "0.000";
summary.getRange("B26:B32").format.numberFormat = "0.000";
summary.getRange("B37:B40").format.numberFormat = "0.000";
summary.getRange("C45:C49").format.numberFormat = "0.0";
summary.getRange("A1:F49").format.font = { name: fontFamily };
summary.getRange("A1:F49").format.autofitRows();
summary.getRange("A:A").format.columnWidth = 38;
summary.getRange("B:B").format.columnWidth = 18;
summary.getRange("C:C").format.columnWidth = 48;
summary.getRange("D:F").format.columnWidth = 18;
summary.freezePanes.freezeRows(2);

const chartModels = ["CFA-RGSE (full)", "RandomForest", "ExtraTrees", "GradientBoosting", "Median", "Ridge"];
summary.getRange("T2:U8").values = [
  ["Capacity model", "RMSE"],
  ...chartModels.map((name) => {
    const row = findRow(capSummary, name);
    return [name, row.rmse_mean];
  }),
];
summary.getRange("T11:U17").values = [
  ["Production model", "RMSE"],
  ...chartModels.map((name) => {
    const row = findRow(prodSummary, name);
    return [name, row.rmse_mean];
  }),
];
const capChart = summary.charts.add("bar", summary.getRange("T2:U8"));
capChart.title = "Capacity: held-out-state RMSE";
capChart.titleTextStyle.typeface = fontFamily;
capChart.hasLegend = false;
capChart.setPosition("H3", "N18");
const prodChart = summary.charts.add("bar", summary.getRange("T11:U17"));
prodChart.title = "Production: held-out-state RMSE";
prodChart.titleTextStyle.typeface = fontFamily;
prodChart.hasLegend = false;
prodChart.setPosition("H20", "N35");

dataSheet("Capacity CV", capSummary, {
  title: "Capacity prediction: models and baselines",
  subtitle: "Five-fold state-held-out GroupKFold; metrics are fold means and sample standard deviations.",
  tableName: "CapacityCVTable",
  colorScaleHeader: "rmse_mean",
});
dataSheet("Capacity Ablations", capAblation, {
  title: "Capacity prediction: CFA-RGSE ablations",
  subtitle: "Lower RMSE is better. Negative results are retained rather than hidden.",
  tableName: "CapacityAblationTable",
  colorScaleHeader: "rmse_mean",
  tabColor: "#D97706",
});
dataSheet("Production CV", prodSummary, {
  title: "Exploratory production prediction: models and baselines",
  subtitle: "Only 115 positive labels are available; interpret separately from the primary capacity task.",
  tableName: "ProductionCVTable",
  colorScaleHeader: "rmse_mean",
});
dataSheet("Production Ablations", prodAblation, {
  title: "Exploratory production prediction: CFA-RGSE ablations",
  subtitle: "Lower RMSE is better. The task is exploratory because production labels are sparse.",
  tableName: "ProductionAblationTable",
  colorScaleHeader: "rmse_mean",
  tabColor: "#D97706",
});
dataSheet("Capacity Estimates", capMissing, {
  title: "CFA-RGSE estimates for 108 missing capacity values",
  subtitle: "model_spread_mtpa is ensemble disagreement, not a calibrated confidence interval.",
  tableName: "CapacityEstimateTable",
  colorScaleHeader: "predicted_capacity_mtpa",
});
dataSheet("Production Estimates", prodMissing, {
  title: "Exploratory estimates for 265 missing or invalid production values",
  subtitle: "Rows explicitly flag whether the capacity input was itself model-estimated.",
  tableName: "ProductionEstimateTable",
  colorScaleHeader: "predicted_production_mt",
});
dataSheet("Priority Index", priority, {
  title: "Cement--fly-ash linkage priority index",
  subtitle: "Analyst-defined screening score; 39 rows without state fly-ash data are deliberately not scored.",
  tableName: "PriorityIndexTable",
  colorScaleHeader: "linkage_priority_score",
  tabColor: "#7C3AED",
  freezeColumns: 3,
});
dataSheet("Model Data", modelData, {
  title: "Joined analysis-ready cement-plant dataset",
  subtitle: "380 plants. State fly-ash values are aggregates in LMT; TPP quantities are proximity/capacity features.",
  tableName: "ModelDataTable",
  tabColor: "#2563EB",
  freezeColumns: 3,
});
dataSheet("Major Match Audit", matchAudit, {
  title: "CEA major-cement-plant matching audit",
  subtitle: "Only conservative same-state high-confidence matches enter the major-plant model view.",
  tableName: "MajorMatchAuditTable",
  colorScaleHeader: "combined_score",
  tabColor: "#2563EB",
  freezeColumns: 3,
});

const notes = workbook.worksheets.add("Sources & Notes");
notes.showGridLines = false;
notes.tabColor = "#64748B";
notes.mergeCells("A1:F1");
notes.getRange("A1").values = [["Sources, definitions and limitations"]];
titleStyle(notes.getRange("A1:F1"));
notes.getRange("A3:F3").merge();
notes.getRange("A3").values = [["Source inventory"]];
sectionStyle(notes.getRange("A3:F3"));
notes.getRange("A4:F8").values = [
  ["Dataset", "Rows", "Period/as-of", "Publisher", "Role", "Reference"],
  ["CEA state fly ash", 18, "2024-25", "Central Electricity Authority", "State generation and utilisation", quality.source_urls.fly_ash_report],
  ["CEA thermal power plants", 189, "2024-25", "Central Electricity Authority", "TPP locations and capacities", quality.source_urls.fly_ash_report],
  ["Cement Plants in India", 380, "2024", "Esri India Living Atlas", "Plant geometry, capacity, production", quality.source_urls.cement_layer],
  ["CEA major cement plants", 141, "2025-10-20", "Central Electricity Authority", "Indicative major-plant list", "CEA Annexure 2 in the supplied source package"],
];
notes.getRange("A10:F10").merge();
notes.getRange("A10").values = [["CFA-RGSE definition"]];
sectionStyle(notes.getRange("A10:F10"));
notes.getRange("A11:B17").values = [
  ["Item", "Definition"],
  ["Name", "Cement--Fly-Ash Reliability-Gated Spatial Ensemble"],
  ["Views", "Plant morphology/geography; state fly ash; TPP proximity; high-confidence CEA-major match"],
  ["Gate", "Inner state-grouped CV error plus observation-level tree disagreement"],
  ["Outer validation", "Five-fold GroupKFold with state as the group"],
  ["Primary target", "Installed cement capacity in million tonnes per annum"],
  ["Secondary target", "Source-reported production in million-tonne units; exploratory"],
];
notes.getRange("A19:F19").merge();
notes.getRange("A19").values = [["Critical limitations"]];
sectionStyle(notes.getRange("A19:F19"), "#B45309");
notes.getRange("A20:B26").values = [
  ["No.", "Limitation"],
  [1, "State fly-ash values are aggregates in lakh metric tonnes, not plant-level ash measurements."],
  [2, "The CEA major-cement list is indicative and inexhaustive; unmatched does not mean non-major."],
  [3, "Two negative source production values are treated as missing sentinels."],
  [4, "Model-spread fields are ensemble disagreement, not calibrated confidence intervals."],
  [5, "The linkage-priority score is an explicit analyst-defined screening index, not a learned outcome."],
  [6, "The observational dataset supports prediction and prioritisation, not causal claims."],
];
for (const headerRange of ["A4:F4", "A11:B11", "A20:B20"]) {
  notes.getRange(headerRange).format = {
    fill: lightGray,
    font: { name: fontFamily, bold: true, color: "#111827" },
    borders: { preset: "all", style: "thin", color: border },
  };
}
notes.getRange("A4:F8").format.borders = { preset: "all", style: "thin", color: "#E5E7EB" };
notes.getRange("A11:B17").format.borders = { preset: "all", style: "thin", color: "#E5E7EB" };
notes.getRange("A20:B26").format.borders = { preset: "all", style: "thin", color: "#E5E7EB" };
notes.getRange("A1:F26").format.font = { name: fontFamily, size: 10 };
notes.getRange("A1:F26").format.wrapText = true;
notes.getRange("A:A").format.columnWidth = 28;
notes.getRange("B:B").format.columnWidth = 60;
notes.getRange("C:C").format.columnWidth = 18;
notes.getRange("D:E").format.columnWidth = 28;
notes.getRange("F:F").format.columnWidth = 60;
notes.getRange("A1:F26").format.autofitRows();
notes.freezePanes.freezeRows(3);

workbook.recalculate();

const summaryCheck = await workbook.inspect({
  kind: "table",
  range: "Summary!A1:F49",
  include: "values,formulas",
  tableMaxRows: 55,
  tableMaxCols: 8,
});
console.log(summaryCheck.ndjson);

const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!",
  options: { useRegex: true, maxResults: 300 },
  summary: "final formula error scan",
});
console.log(errors.ndjson);

const previewRanges = {
  "Summary": "A1:N49",
  "Capacity CV": "A1:J15",
  "Capacity Ablations": "A1:J12",
  "Production CV": "A1:J15",
  "Production Ablations": "A1:J12",
  "Capacity Estimates": "A1:Q20",
  "Production Estimates": "A1:P20",
  "Priority Index": "A1:Z18",
  "Model Data": "A1:Q18",
  "Major Match Audit": "A1:L18",
  "Sources & Notes": "A1:F26",
};
for (const [sheetName, range] of Object.entries(previewRanges)) {
  const preview = await workbook.render({ sheetName, range, scale: 1, format: "png" });
  const safeName = sheetName.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
  await fs.writeFile(
    path.join(outputDir, "workbook_previews", `${safeName}.png`),
    new Uint8Array(await preview.arrayBuffer()),
  );
}

const xlsx = await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(path.join(outputDir, "Cement_FlyAsh_Real_Research_Workbook.xlsx"));
console.log("Workbook exported successfully.");
