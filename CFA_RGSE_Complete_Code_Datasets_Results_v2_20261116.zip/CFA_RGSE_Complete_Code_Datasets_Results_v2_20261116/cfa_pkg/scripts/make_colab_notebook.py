"""Generate a Colab notebook that reruns the packaged real-data experiment."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "notebooks" / "CFA_RGSE_Real_Experiment_Colab.ipynb"


def md(text: str) -> dict:
    return {"cell_type": "markdown", "metadata": {}, "source": text.splitlines(True)}


def code(text: str) -> dict:
    return {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": text.splitlines(True),
    }


def main() -> None:
    cells = [
        md(
            "# CFA-RGSE: India cement--fly-ash real-data experiment\n\n"
            "This notebook reruns the complete project using the four packaged source "
            "CSVs. The primary task estimates missing cement-plant capacity; production "
            "is a secondary exploratory task. Evaluation uses state-held-out GroupKFold, "
            "with baselines, ablations and state-cluster bootstrap statistics."
        ),
        md(
            "## 1. Upload the research package\n\n"
            "Upload `Cement_FlyAsh_Research_Package.zip` when the chooser appears."
        ),
        code(
            "from google.colab import files\n"
            "uploaded = files.upload()\n"
            "zip_names = [name for name in uploaded if name.lower().endswith('.zip')]\n"
            "assert zip_names, 'Please upload Cement_FlyAsh_Research_Package.zip'\n"
            "zip_name = zip_names[0]\n"
            "!mkdir -p /content/cement_flyash_research\n"
            "!unzip -q -o \"$zip_name\" -d /content/cement_flyash_research\n"
            "%cd /content/cement_flyash_research\n"
        ),
        md("## 2. Install and record the environment"),
        code(
            "!pip -q install -r requirements.txt\n"
            "import json, platform, numpy, pandas, scipy, sklearn, matplotlib\n"
            "print({\n"
            "    'python': platform.python_version(),\n"
            "    'numpy': numpy.__version__,\n"
            "    'pandas': pandas.__version__,\n"
            "    'scipy': scipy.__version__,\n"
            "    'scikit-learn': sklearn.__version__,\n"
            "    'matplotlib': matplotlib.__version__,\n"
            "})\n"
        ),
        md("## 3. Build and audit the joined dataset"),
        code(
            "!python scripts/build_dataset.py\n"
            "from pathlib import Path\n"
            "quality = json.loads(Path('data/processed/data_quality_report.json').read_text())\n"
            "quality\n"
        ),
        md("## 4. Train the primary capacity models and ablations"),
        code(
            "!python scripts/train_capacity_models.py\n"
            "capacity_results = pandas.read_csv('results/capacity_group_cv_summary.csv')\n"
            "capacity_results.style.format({c: '{:.3f}' for c in capacity_results.columns if c not in ['model', 'folds']})\n"
        ),
        md("## 5. Train the secondary exploratory production models"),
        code(
            "!python scripts/train_production_models.py\n"
            "production_results = pandas.read_csv('results/production_group_cv_summary.csv')\n"
            "production_results.style.format({c: '{:.3f}' for c in production_results.columns if c not in ['model', 'folds']})\n"
        ),
        md("## 6. Build the transparent linkage-priority index"),
        code(
            "!python scripts/build_priority_index.py\n"
            "priority = pandas.read_csv('results/cement_flyash_linkage_priority_top25.csv')\n"
            "priority[['linkage_priority_rank','name','state_canonical','linkage_priority_score','capacity_value_type']].head(25)\n"
        ),
        md("## 7. Statistical comparisons and publication-ready figures"),
        code(
            "!python scripts/analyze_results.py\n"
            "from IPython.display import Image, display\n"
            "for plot in [\n"
            "    'results/plots/capacity_baseline_comparison.png',\n"
            "    'results/plots/capacity_ablation.png',\n"
            "    'results/plots/production_baseline_comparison.png',\n"
            "    'results/plots/production_ablation.png',\n"
            "]:\n"
            "    display(Image(filename=plot))\n"
        ),
        md(
            "## 8. Inspect paired uncertainty\n\n"
            "A confidence interval crossing zero means the proposed model's advantage "
            "is not statistically decisive under state-cluster resampling."
        ),
        code(
            "for task in ['capacity', 'production']:\n"
            "    stats = json.loads(Path(f'results/{task}_paired_statistics.json').read_text())\n"
            "    print(task.upper())\n"
            "    print(json.dumps(stats, indent=2), '\\n')\n"
        ),
        md("## 9. Download all generated results"),
        code(
            "!zip -q -r /content/CFA_RGSE_generated_results.zip data/processed results README.md\n"
            "files.download('/content/CFA_RGSE_generated_results.zip')\n"
        ),
    ]
    notebook = {
        "cells": cells,
        "metadata": {
            "colab": {"name": OUTPUT.name, "provenance": []},
            "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python", "version": "3.x"},
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(notebook, indent=2), encoding="utf-8")
    print(f"Saved {OUTPUT}")


if __name__ == "__main__":
    main()
