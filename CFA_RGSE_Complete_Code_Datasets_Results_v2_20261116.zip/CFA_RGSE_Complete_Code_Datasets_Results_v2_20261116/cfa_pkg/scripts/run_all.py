"""Run the complete reproducible research pipeline in dependency order."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
STEPS = [
    "build_dataset.py",
    "train_capacity_models.py",
    "train_production_models.py",
    "build_priority_index.py",
    "analyze_results.py",
]


def main() -> None:
    for script in STEPS:
        print(f"\n=== Running {script} ===", flush=True)
        subprocess.run(
            [sys.executable, str(ROOT / "scripts" / script)],
            cwd=ROOT,
            check=True,
        )
    print("\nPipeline completed. Outputs are in data/processed and results.")


if __name__ == "__main__":
    main()
