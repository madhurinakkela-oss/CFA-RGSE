#!/usr/bin/env python3
"""Run leakage-aware baselines and CFA-RGSE capacity-model ablations.

CFA-RGSE: Cement–Fly-Ash Reliability-Gated Spatial Ensemble.
The model combines plant, state fly-ash, thermal-power proximity, and
high-confidence CEA major-plant views. View weights use inner-CV error and
tree disagreement; a conservative spatial residual step is learned only from
outer-training data.
"""

from __future__ import annotations

import argparse
import json
import math
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import (
    ExtraTreesRegressor,
    GradientBoostingRegressor,
    HistGradientBoostingRegressor,
    RandomForestRegressor,
)
from sklearn.exceptions import ConvergenceWarning
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GroupKFold
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


SEED = 42
TARGET = "capacity_mtpa_target"
GROUP = "state_canonical"

CORE_FEATURES = [
    "st_area(shape)",
    "st_perimeter(shape)",
    "centroid_longitude",
    "centroid_latitude",
]

FLYASH_FEATURES = [
    "state_tpp_count_reported",
    "state_coal_consumed_lmt",
    "state_ash_generation_lmt",
    "state_ash_utilisation_lmt",
    "state_ash_utilisation_percent",
    "state_flyash_data_available",
]

TPP_FEATURES = [
    "nearest_tpp_distance_km",
    "nearest_tpp_capacity_mw",
    "nearest_tpp_same_state",
    "tpp_count_within_50km",
    "tpp_capacity_within_50km_mw",
    "tpp_count_within_100km",
    "tpp_capacity_within_100km_mw",
    "tpp_count_within_200km",
    "tpp_capacity_within_200km_mw",
    "nearest_pithead_tpp_distance_km",
    "nearest_nonpithead_tpp_distance_km",
]

MAJOR_FEATURES = [
    "cea_major_match_high_confidence",
    "cea_major_match_score",
    "cea_major_company_score",
    "cea_major_location_score",
]

VIEW_FEATURES = {
    "plant": CORE_FEATURES,
    "flyash": CORE_FEATURES + FLYASH_FEATURES,
    "tpp": CORE_FEATURES + TPP_FEATURES,
    "major": CORE_FEATURES + MAJOR_FEATURES,
}

ALL_NUMERIC = CORE_FEATURES + FLYASH_FEATURES + TPP_FEATURES + MAJOR_FEATURES
ALL_CATEGORICAL = ["state_canonical", "geometry_type"]

RESIDUAL_FEATURES = [
    "centroid_longitude",
    "centroid_latitude",
    "nearest_tpp_distance_km",
    "state_ash_generation_lmt",
    "st_area(shape)",
]


def make_one_hot() -> OneHotEncoder:
    try:
        return OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError:
        return OneHotEncoder(handle_unknown="ignore", sparse=False)


def full_preprocessor(scale: bool) -> ColumnTransformer:
    numeric_steps: list[tuple[str, object]] = [
        ("imputer", SimpleImputer(strategy="median", add_indicator=True))
    ]
    if scale:
        numeric_steps.append(("scaler", StandardScaler()))
    return ColumnTransformer(
        [
            ("num", Pipeline(numeric_steps), ALL_NUMERIC),
            (
                "cat",
                Pipeline(
                    [
                        ("imputer", SimpleImputer(strategy="most_frequent")),
                        ("onehot", make_one_hot()),
                    ]
                ),
                ALL_CATEGORICAL,
            ),
        ],
        remainder="drop",
    )


def baseline_models(seed: int) -> dict[str, Pipeline]:
    return {
        "Median": Pipeline(
            [("prep", full_preprocessor(scale=False)), ("model", DummyRegressor(strategy="median"))]
        ),
        "Ridge": Pipeline(
            [("prep", full_preprocessor(scale=True)), ("model", Ridge(alpha=10.0))]
        ),
        "RandomForest": Pipeline(
            [
                ("prep", full_preprocessor(scale=False)),
                (
                    "model",
                    RandomForestRegressor(
                        n_estimators=350,
                        min_samples_leaf=2,
                        max_features=0.75,
                        random_state=seed,
                        n_jobs=-1,
                    ),
                ),
            ]
        ),
        "ExtraTrees": Pipeline(
            [
                ("prep", full_preprocessor(scale=False)),
                (
                    "model",
                    ExtraTreesRegressor(
                        n_estimators=350,
                        min_samples_leaf=2,
                        max_features=0.85,
                        random_state=seed,
                        n_jobs=-1,
                    ),
                ),
            ]
        ),
        "GradientBoosting": Pipeline(
            [
                ("prep", full_preprocessor(scale=False)),
                (
                    "model",
                    GradientBoostingRegressor(
                        n_estimators=180,
                        learning_rate=0.035,
                        max_depth=2,
                        loss="huber",
                        random_state=seed,
                    ),
                ),
            ]
        ),
        "MLP": Pipeline(
            [
                ("prep", full_preprocessor(scale=True)),
                (
                    "model",
                    MLPRegressor(
                        hidden_layer_sizes=(48, 24),
                        alpha=0.02,
                        learning_rate_init=0.003,
                        max_iter=1000,
                        early_stopping=True,
                        validation_fraction=0.18,
                        random_state=seed,
                    ),
                ),
            ]
        ),
    }


def make_view_model(features: list[str], seed: int) -> Pipeline:
    return Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
            (
                "model",
                ExtraTreesRegressor(
                    n_estimators=280,
                    min_samples_leaf=2,
                    max_features=0.85,
                    random_state=seed,
                    n_jobs=-1,
                ),
            ),
        ]
    )


def tree_prediction_distribution(model: Pipeline, x: pd.DataFrame) -> np.ndarray:
    transformed = model.named_steps["imputer"].transform(x)
    forest = model.named_steps["model"]
    log_predictions = np.column_stack([tree.predict(transformed) for tree in forest.estimators_])
    return np.clip(np.expm1(log_predictions), 0.0, None)


def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    return {
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "rmse": float(math.sqrt(mean_squared_error(y_true, y_pred))),
        "r2": float(r2_score(y_true, y_pred)),
        "mape_percent": float(np.mean(np.abs((y_true - y_pred) / y_true)) * 100.0),
    }


def inner_view_predictions(
    x_train: pd.DataFrame,
    y_train: np.ndarray,
    groups: np.ndarray,
    x_test: pd.DataFrame,
    seed: int,
) -> dict:
    unique_groups = np.unique(groups)
    n_splits = min(4, len(unique_groups))
    inner = GroupKFold(n_splits=n_splits)
    view_data: dict[str, dict[str, np.ndarray | float | Pipeline]] = {}

    for view_index, (view_name, features) in enumerate(VIEW_FEATURES.items()):
        oof_mean = np.full(len(x_train), np.nan)
        oof_var = np.full(len(x_train), np.nan)
        for inner_fold, (fit_idx, val_idx) in enumerate(inner.split(x_train, y_train, groups)):
            model = make_view_model(features, seed + 101 * view_index + inner_fold)
            model.fit(x_train.iloc[fit_idx][features], np.log1p(y_train[fit_idx]))
            distribution = tree_prediction_distribution(model, x_train.iloc[val_idx][features])
            oof_mean[val_idx] = distribution.mean(axis=1)
            oof_var[val_idx] = distribution.var(axis=1)

        full_model = make_view_model(features, seed + 1000 + view_index)
        full_model.fit(x_train[features], np.log1p(y_train))
        test_distribution = tree_prediction_distribution(full_model, x_test[features])
        view_rmse = math.sqrt(mean_squared_error(y_train, oof_mean))
        view_data[view_name] = {
            "oof_mean": oof_mean,
            "oof_var": oof_var,
            "test_mean": test_distribution.mean(axis=1),
            "test_var": test_distribution.var(axis=1),
            "rmse": float(view_rmse),
            "model": full_model,
        }
    return view_data


def reliability_blend(
    view_data: dict,
    dataset: pd.DataFrame,
    prediction_side: str,
    active_views: list[str],
    reliability: bool,
    rmse_power: float = 2.0,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    means = np.column_stack([view_data[name][f"{prediction_side}_mean"] for name in active_views])
    variances = np.column_stack([view_data[name][f"{prediction_side}_var"] for name in active_views])

    if reliability:
        base = np.array([1.0 / (view_data[name]["rmse"] ** rmse_power + 1e-8) for name in active_views])
        weights = np.tile(base, (len(dataset), 1))
        weights = weights / (1.0 + variances / (np.square(np.array([view_data[n]["rmse"] for n in active_views])) + 1e-8))
        if "flyash" in active_views:
            idx = active_views.index("flyash")
            availability = dataset["state_flyash_data_available"].to_numpy(float)
            weights[:, idx] *= np.where(availability > 0, 1.0, 0.10)
        if "major" in active_views:
            idx = active_views.index("major")
            availability = dataset["cea_major_match_high_confidence"].to_numpy(float)
            weights[:, idx] *= np.where(availability > 0, 1.0, 0.35)
    else:
        weights = np.ones_like(means)

    weights = weights / np.clip(weights.sum(axis=1, keepdims=True), 1e-12, None)
    prediction = np.sum(weights * means, axis=1)
    within_view = np.sum(weights * variances, axis=1)
    between_view = np.sum(weights * np.square(means - prediction[:, None]), axis=1)
    spread = np.sqrt(np.clip(within_view + between_view, 0.0, None))
    return prediction, spread, weights


def select_reliability_power(
    view_data: dict,
    x_train: pd.DataFrame,
    y_train: np.ndarray,
    active_views: list[str],
) -> float:
    """Choose gate sharpness using inner out-of-fold predictions only."""
    candidates = (1.0, 2.0, 4.0, 8.0)
    scores = {}
    for power in candidates:
        prediction, _, _ = reliability_blend(
            view_data,
            x_train,
            "oof",
            active_views,
            True,
            rmse_power=power,
        )
        scores[power] = math.sqrt(mean_squared_error(y_train, prediction))
    return min(scores, key=scores.get)


def spatial_residual_correction(
    x_train: pd.DataFrame,
    y_train: np.ndarray,
    train_prediction: np.ndarray,
    x_test: pd.DataFrame,
    test_prediction: np.ndarray,
    alpha: float = 0.30,
) -> tuple[np.ndarray, np.ndarray]:
    residual = y_train - train_prediction
    neighbors = min(9, max(3, len(x_train) // 25))
    model = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
            ("scaler", StandardScaler()),
            ("knn", KNeighborsRegressor(n_neighbors=neighbors, weights="distance", p=2)),
        ]
    )
    model.fit(x_train[RESIDUAL_FEATURES], residual)
    correction = model.predict(x_test[RESIDUAL_FEATURES])
    low, high = np.quantile(residual, [0.10, 0.90])
    correction = np.clip(correction, low, high)
    corrected = np.clip(test_prediction + alpha * correction, 0.0, None)
    return corrected, correction


def predict_variant(
    view_data: dict,
    x_train: pd.DataFrame,
    y_train: np.ndarray,
    x_test: pd.DataFrame,
    active_views: list[str],
    reliability: bool,
    spatial: bool,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    rmse_power = (
        select_reliability_power(view_data, x_train, y_train, active_views)
        if reliability
        else 2.0
    )
    train_pred, _, _ = reliability_blend(
        view_data, x_train, "oof", active_views, reliability, rmse_power=rmse_power
    )
    test_pred, spread, weights = reliability_blend(
        view_data, x_test, "test", active_views, reliability, rmse_power=rmse_power
    )
    if spatial:
        test_pred, _ = spatial_residual_correction(
            x_train, y_train, train_pred, x_test, test_pred
        )
    return test_pred, spread, weights


VARIANTS = {
    "CFA-RGSE (full)": {"views": ["plant", "flyash", "tpp", "major"], "reliability": True, "spatial": False},
    "w/o reliability gate": {"views": ["plant", "flyash", "tpp", "major"], "reliability": False, "spatial": False},
    "w/o fly-ash view": {"views": ["plant", "tpp", "major"], "reliability": True, "spatial": False},
    "w/o TPP proximity view": {"views": ["plant", "flyash", "major"], "reliability": True, "spatial": False},
    "w/o CEA-major view": {"views": ["plant", "flyash", "tpp"], "reliability": True, "spatial": False},
    "with spatial residual correction": {"views": ["plant", "flyash", "tpp", "major"], "reliability": True, "spatial": True},
}


def summarize(fold_metrics: pd.DataFrame) -> pd.DataFrame:
    metric_cols = ["mae", "rmse", "r2", "mape_percent"]
    rows = []
    for model_name, group in fold_metrics.groupby("model", sort=False):
        row: dict[str, float | str | int] = {"model": model_name, "folds": int(len(group))}
        for metric in metric_cols:
            row[f"{metric}_mean"] = float(group[metric].mean())
            row[f"{metric}_std"] = float(group[metric].std(ddof=1))
        rows.append(row)
    return pd.DataFrame(rows).sort_values("rmse_mean").reset_index(drop=True)


def run_group_cv(data: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    labelled = data.loc[data[TARGET].notna()].reset_index(drop=True)
    y = labelled[TARGET].to_numpy(float)
    groups = labelled[GROUP].to_numpy()
    outer = GroupKFold(n_splits=5)
    records: list[dict] = []
    prediction_records: list[dict] = []

    for fold, (train_idx, test_idx) in enumerate(outer.split(labelled, y, groups), start=1):
        x_train, x_test = labelled.iloc[train_idx], labelled.iloc[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        held_out_states = sorted(x_test[GROUP].unique().tolist())

        for model_offset, (name, model) in enumerate(baseline_models(SEED + fold).items()):
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", ConvergenceWarning)
                model.fit(x_train, np.log1p(y_train))
            pred = np.clip(np.expm1(model.predict(x_test)), 0.0, None)
            records.append(
                {
                    "evaluation": "state-held-out GroupKFold",
                    "fold": fold,
                    "model": name,
                    "n_train": len(train_idx),
                    "n_test": len(test_idx),
                    "held_out_states": "; ".join(held_out_states),
                    **regression_metrics(y_test, pred),
                }
            )
            for position, prediction in zip(test_idx, pred):
                prediction_records.append(
                    {
                        "objectid": int(labelled.loc[position, "objectid"]),
                        "name": labelled.loc[position, "name"],
                        "state_canonical": labelled.loc[position, GROUP],
                        "fold": fold,
                        "model": name,
                        "y_true": float(labelled.loc[position, TARGET]),
                        "y_pred": float(prediction),
                        "absolute_error": float(abs(labelled.loc[position, TARGET] - prediction)),
                    }
                )

        view_data = inner_view_predictions(
            x_train, y_train, groups[train_idx], x_test, SEED + 100 * fold
        )
        for variant_name, config in VARIANTS.items():
            pred, _, _ = predict_variant(
                view_data,
                x_train,
                y_train,
                x_test,
                config["views"],
                config["reliability"],
                config["spatial"],
            )
            records.append(
                {
                    "evaluation": "state-held-out GroupKFold",
                    "fold": fold,
                    "model": variant_name,
                    "n_train": len(train_idx),
                    "n_test": len(test_idx),
                    "held_out_states": "; ".join(held_out_states),
                    **regression_metrics(y_test, pred),
                }
            )
            for position, prediction in zip(test_idx, pred):
                prediction_records.append(
                    {
                        "objectid": int(labelled.loc[position, "objectid"]),
                        "name": labelled.loc[position, "name"],
                        "state_canonical": labelled.loc[position, GROUP],
                        "fold": fold,
                        "model": variant_name,
                        "y_true": float(labelled.loc[position, TARGET]),
                        "y_pred": float(prediction),
                        "absolute_error": float(abs(labelled.loc[position, TARGET] - prediction)),
                    }
                )

    folds = pd.DataFrame(records)
    predictions = pd.DataFrame(prediction_records)
    return folds, summarize(folds), predictions


def fit_full_and_predict_missing(data: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    labelled = data.loc[data[TARGET].notna()].reset_index(drop=True)
    missing = data.loc[data[TARGET].isna()].copy().reset_index(drop=True)
    y = labelled[TARGET].to_numpy(float)
    groups = labelled[GROUP].to_numpy()
    view_data = inner_view_predictions(labelled, y, groups, missing, SEED + 9000)
    config = VARIANTS["CFA-RGSE (full)"]
    prediction, spread, weights = predict_variant(
        view_data,
        labelled,
        y,
        missing,
        config["views"],
        config["reliability"],
        config["spatial"],
    )

    result = missing[
        [
            "objectid",
            "uid",
            "name",
            "district",
            "state_canonical",
            "centroid_longitude",
            "centroid_latitude",
            "nearest_tpp_distance_km",
            "state_ash_generation_lmt",
            "cea_major_match_high_confidence",
        ]
    ].copy()
    result["predicted_capacity_mtpa"] = prediction
    result["model_spread_mtpa"] = spread
    for idx, view in enumerate(config["views"]):
        result[f"weight_{view}"] = weights[:, idx]
    result["prediction_status"] = "model estimate; source capacity missing"

    metadata = {
        "model": "CFA-RGSE",
        "target": TARGET,
        "training_rows": int(len(labelled)),
        "predicted_missing_rows": int(len(missing)),
        "view_inner_cv_rmse": {
            name: float(view_data[name]["rmse"]) for name in config["views"]
        },
        "uncertainty_note": "model_spread_mtpa is ensemble disagreement, not a calibrated confidence interval",
    }
    return result, metadata


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, default=Path("data/processed/cement_flyash_model_dataset.csv"))
    parser.add_argument("--results-dir", type=Path, default=Path("results"))
    args = parser.parse_args()
    args.results_dir.mkdir(parents=True, exist_ok=True)

    data = pd.read_csv(args.dataset)
    folds, summary, oof_predictions = run_group_cv(data)
    missing_predictions, full_metadata = fit_full_and_predict_missing(data)

    folds.to_csv(args.results_dir / "capacity_group_cv_fold_metrics.csv", index=False)
    summary.to_csv(args.results_dir / "capacity_group_cv_summary.csv", index=False)
    oof_predictions.to_csv(args.results_dir / "capacity_group_cv_oof_predictions.csv", index=False)
    summary.loc[
        summary["model"].str.startswith("CFA-RGSE")
        | summary["model"].str.startswith("w/o")
        | summary["model"].str.startswith("with")
    ].to_csv(
        args.results_dir / "capacity_ablation_summary.csv", index=False
    )
    missing_predictions.to_csv(args.results_dir / "capacity_missing_predictions.csv", index=False)

    manifest = {
        "seed": SEED,
        "primary_evaluation": "5-fold state-held-out GroupKFold",
        "target": "installed capacity in million tonnes per annum",
        "target_column": TARGET,
        "features_excluded_to_prevent leakage": [
            "capacitym",
            "capacityt",
            "capacity_mtpa_source",
            "production",
            "production_mt_source",
            "production_mt_target",
        ],
        "proposed_model": full_metadata,
    }
    with (args.results_dir / "capacity_model_manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)

    print(summary.to_string(index=False))
    print("\nSaved predictions:", len(missing_predictions))


if __name__ == "__main__":
    main()
