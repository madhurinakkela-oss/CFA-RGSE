#!/usr/bin/env python3
"""Secondary, exploratory production model using valid source production rows.

This task is reported separately from the primary capacity task because only
115 positive production labels are available. Missing capacity inputs are
filled only for inference, using the primary model's saved estimates.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

import train_capacity_models as core


def configure_production_task() -> None:
    core.TARGET = "production_mt_target"
    capacity = ["capacity_mtpa_target"]
    core.CORE_FEATURES = capacity + [
        "st_area(shape)",
        "st_perimeter(shape)",
        "centroid_longitude",
        "centroid_latitude",
    ]
    core.VIEW_FEATURES = {
        "plant": core.CORE_FEATURES,
        "flyash": core.CORE_FEATURES + core.FLYASH_FEATURES,
        "tpp": core.CORE_FEATURES + core.TPP_FEATURES,
        "major": core.CORE_FEATURES + core.MAJOR_FEATURES,
    }
    core.ALL_NUMERIC = (
        core.CORE_FEATURES + core.FLYASH_FEATURES + core.TPP_FEATURES + core.MAJOR_FEATURES
    )
    core.RESIDUAL_FEATURES = capacity + [
        "centroid_longitude",
        "centroid_latitude",
        "nearest_tpp_distance_km",
        "state_ash_generation_lmt",
        "st_area(shape)",
    ]


def add_sequential_capacity_estimates(data: pd.DataFrame, capacity_predictions: Path) -> pd.DataFrame:
    estimates = pd.read_csv(capacity_predictions)[["objectid", "predicted_capacity_mtpa"]]
    out = data.merge(estimates, on="objectid", how="left", validate="one_to_one")
    out["capacity_input_was_estimated"] = out["capacity_mtpa_target"].isna().astype(int)
    out["capacity_mtpa_target"] = out["capacity_mtpa_target"].fillna(
        out["predicted_capacity_mtpa"]
    )
    return out


def fit_full_and_predict(data: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    labelled = data.loc[data[core.TARGET].notna()].reset_index(drop=True)
    missing = data.loc[data[core.TARGET].isna()].copy().reset_index(drop=True)
    y = labelled[core.TARGET].to_numpy(float)
    groups = labelled[core.GROUP].to_numpy()
    view_data = core.inner_view_predictions(labelled, y, groups, missing, core.SEED + 12000)
    config = core.VARIANTS["CFA-RGSE (full)"]
    prediction, spread, weights = core.predict_variant(
        view_data,
        labelled,
        y,
        missing,
        config["views"],
        config["reliability"],
        config["spatial"],
    )

    result = missing[
        [
            "objectid",
            "uid",
            "name",
            "district",
            "state_canonical",
            "capacity_mtpa_target",
            "capacity_input_was_estimated",
            "nearest_tpp_distance_km",
            "state_ash_generation_lmt",
        ]
    ].copy()
    result["predicted_production_mt"] = prediction
    result["model_spread_mt"] = spread
    for idx, view in enumerate(config["views"]):
        result[f"weight_{view}"] = weights[:, idx]
    result["prediction_status"] = "exploratory model estimate; source production missing or invalid"

    metadata = {
        "training_rows": int(len(labelled)),
        "predicted_rows": int(len(missing)),
        "capacity_estimates_used_for_inference_rows": int(
            missing["capacity_input_was_estimated"].sum()
        ),
        "uncertainty_note": "model_spread_mt is ensemble disagreement, not a calibrated confidence interval",
    }
    return result, metadata


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, default=Path("data/processed/cement_flyash_model_dataset.csv"))
    parser.add_argument(
        "--capacity-predictions",
        type=Path,
        default=Path("results/capacity_missing_predictions.csv"),
    )
    parser.add_argument("--results-dir", type=Path, default=Path("results"))
    args = parser.parse_args()
    args.results_dir.mkdir(parents=True, exist_ok=True)

    configure_production_task()
    data = pd.read_csv(args.dataset)
    data = add_sequential_capacity_estimates(data, args.capacity_predictions)
    folds, summary, oof_predictions = core.run_group_cv(data)
    predictions, metadata = fit_full_and_predict(data)

    folds.to_csv(args.results_dir / "production_group_cv_fold_metrics.csv", index=False)
    summary.to_csv(args.results_dir / "production_group_cv_summary.csv", index=False)
    oof_predictions.to_csv(args.results_dir / "production_group_cv_oof_predictions.csv", index=False)
    summary.loc[
        summary["model"].str.startswith("CFA-RGSE")
        | summary["model"].str.startswith("w/o")
        | summary["model"].str.startswith("with")
    ].to_csv(args.results_dir / "production_ablation_summary.csv", index=False)
    predictions.to_csv(args.results_dir / "production_missing_predictions.csv", index=False)

    manifest = {
        "seed": core.SEED,
        "status": "secondary exploratory task because only 115 positive labels are available",
        "primary_evaluation": "5-fold state-held-out GroupKFold",
        "target": "cement production in source-reported million-tonne units",
        "target_column": core.TARGET,
        "capacity_is_an_input": True,
        "inference": metadata,
    }
    with (args.results_dir / "production_model_manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)

    print(summary.to_string(index=False))
    print("\nSaved exploratory predictions:", len(predictions))


if __name__ == "__main__":
    main()
