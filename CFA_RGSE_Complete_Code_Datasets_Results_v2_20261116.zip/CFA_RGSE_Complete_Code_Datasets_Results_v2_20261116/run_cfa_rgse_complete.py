#!/usr/bin/env python3
"""Run the complete CFA-RGSE reproducibility workflow.

The core pipeline reproduces the manuscript's audited dataset, state-held-out
models, ablations, missing-value estimates, priority index, and base plots.
The extension pipeline adds the exploratory graph sensitivity study, the
nested graph-scale experiment, and the scenario-labelled allocation figures.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def run(script: Path, env: dict[str, str]) -> None:
    print(f"\n=== Running {script.relative_to(ROOT)} ===", flush=True)
    subprocess.run([sys.executable, str(script)], cwd=ROOT, env=env, check=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--core-only",
        action="store_true",
        help="Run only the results reported in CFA_RGSE_HA_final.docx.",
    )
    args = parser.parse_args()

    env = os.environ.copy()
    env.setdefault("MPLBACKEND", "Agg")

    run(ROOT / "cfa_pkg/scripts/run_all.py", env)
    if not args.core_only:
        run(ROOT / "run_graph_spatial_lag_experiment.py", env)
        run(ROOT / "run_nested_graph_scale_experiment.py", env)
        run(ROOT / "build_q1_extension_artifacts.py", env)
    run(ROOT / "validate_cfa_rgse_package.py", env)
    print("\nCFA-RGSE complete workflow: PASS", flush=True)


if __name__ == "__main__":
    main()
