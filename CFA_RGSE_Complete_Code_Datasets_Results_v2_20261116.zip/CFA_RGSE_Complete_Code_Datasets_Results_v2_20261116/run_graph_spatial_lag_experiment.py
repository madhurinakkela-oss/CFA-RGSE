#!/usr/bin/env python3
"""Evaluate a target-free bipartite graph spatial-lag view for CFA-RGSE.

The graph uses only public covariates: cement/TPP coordinates, TPP capacities,
pithead class, plant geometry, and state fly-ash aggregates. Capacity and
production targets are excluded from graph construction.
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GroupKFold

ROOT = Path(__file__).resolve().parent
PKG = ROOT / "cfa_pkg"
sys.path.insert(0, str(PKG / "scripts"))
import train_capacity_models as base  # noqa: E402


def haversine_matrix(lat1, lon1, lat2, lon2):
    lat1 = np.radians(np.asarray(lat1, dtype=float))[:, None]
    lon1 = np.radians(np.asarray(lon1, dtype=float))[:, None]
    lat2 = np.radians(np.asarray(lat2, dtype=float))[None, :]
    lon2 = np.radians(np.asarray(lon2, dtype=float))[None, :]
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat / 2.0) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2.0) ** 2
    return 6371.0088 * 2.0 * np.arcsin(np.sqrt(np.clip(a, 0.0, 1.0)))


def median_fill(x):
    x = np.asarray(x, dtype=float)
    med = np.nanmedian(x, axis=0)
    med = np.where(np.isfinite(med), med, 0.0)
    return np.where(np.isfinite(x), x, med)


def build_graph_features(cement, tpp, tau_km=100.0, top_k=12):
    tpp = tpp.loc[tpp[["latitude", "longitude"]].notna().all(axis=1)].copy()
    d = haversine_matrix(
        cement["centroid_latitude"], cement["centroid_longitude"],
        tpp["latitude"], tpp["longitude"],
    )
    cap = tpp["capacity_mw"].fillna(0.0).to_numpy(float)
    pit = tpp["pithead_class"].astype(str).str.upper().str.contains("PH", na=False).to_numpy(float)
    cement_state = cement["state_canonical"].fillna("").astype(str).to_numpy()
    tpp_state = tpp["state"].fillna("").astype(str).to_numpy()

    graph = pd.DataFrame(index=cement.index)
    kernels = {}
    for bandwidth in (50.0, 100.0, 200.0):
        w = np.exp(-np.square(d / bandwidth))
        w[d > 3.0 * bandwidth] = 0.0
        row_sum = np.clip(w.sum(axis=1, keepdims=True), 1e-12, None)
        wn = w / row_sum
        kernels[bandwidth] = wn
        graph[f"graph_tpp_capacity_kernel_{int(bandwidth)}"] = wn @ cap
        graph[f"graph_tpp_distance_kernel_{int(bandwidth)}"] = np.sum(wn * d, axis=1)
        graph[f"graph_pithead_share_{int(bandwidth)}"] = wn @ pit
        same = (cement_state[:, None] == tpp_state[None, :]).astype(float)
        graph[f"graph_same_state_share_{int(bandwidth)}"] = np.sum(wn * same, axis=1)
        graph[f"graph_effective_sources_{int(bandwidth)}"] = 1.0 / np.clip(np.sum(wn**2, axis=1), 1e-12, None)

    b = np.exp(-np.square(d / tau_km))
    b[d > 3.0 * tau_km] = 0.0
    b = b / np.clip(b.sum(axis=1, keepdims=True), 1e-12, None)
    affinity = b @ b.T
    np.fill_diagonal(affinity, 0.0)
    if top_k < len(cement) - 1:
        cut = np.argpartition(affinity, -top_k, axis=1)[:, :-top_k]
        rows = np.arange(len(cement))[:, None]
        affinity[rows, cut] = 0.0
    raw_degree = affinity.sum(axis=1)
    adj = affinity / np.clip(raw_degree[:, None], 1e-12, None)

    source_cols = [
        "st_area(shape)", "st_perimeter(shape)",
        "state_ash_generation_lmt", "state_ash_utilisation_lmt",
        "state_ash_utilisation_percent", "nearest_tpp_distance_km",
        "tpp_capacity_within_100km_mw", "tpp_capacity_within_200km_mw",
        "cea_major_match_score",
    ]
    x = median_fill(cement[source_cols].to_numpy(float))
    x[:, 0] = np.log1p(np.clip(x[:, 0], 0.0, None))
    x[:, 1] = np.log1p(np.clip(x[:, 1], 0.0, None))
    lag = adj @ x
    for j, col in enumerate(source_cols):
        safe = col.lower().replace("(", "_").replace(")", "").replace(" ", "_")
        graph[f"graph_lag_{safe}"] = lag[:, j]
        graph[f"graph_contrast_{safe}"] = x[:, j] - lag[:, j]
    graph["graph_shared_source_degree"] = raw_degree
    graph["graph_shared_source_entropy"] = -np.sum(
        np.where(adj > 0, adj * np.log(np.clip(adj, 1e-12, None)), 0.0), axis=1
    )
    graph["graph_tau_km"] = tau_km
    graph["graph_top_k"] = float(top_k)
    return graph.reset_index(drop=True)


def metrics(y, pred):
    return {
        "mae": float(mean_absolute_error(y, pred)),
        "rmse": float(math.sqrt(mean_squared_error(y, pred))),
        "r2": float(r2_score(y, pred)),
    }


def evaluate(data, graph_cols, seed=42):
    labelled = data.loc[data[base.TARGET].notna()].reset_index(drop=True)
    y = labelled[base.TARGET].to_numpy(float)
    groups = labelled[base.GROUP].to_numpy()
    outer = GroupKFold(n_splits=5)
    records = []
    preds = []

    original_views = dict(base.VIEW_FEATURES)
    base.VIEW_FEATURES = dict(original_views)
    base.VIEW_FEATURES["graph"] = base.CORE_FEATURES + graph_cols
    variants = {
        "CFA-RGSE (full)": ["plant", "flyash", "tpp", "major"],
        "CFA-RGSE-GSL (graph-augmented)": ["plant", "flyash", "tpp", "major", "graph"],
        "CFA-RGSE-GSL (no fly-ash)": ["plant", "tpp", "major", "graph"],
        "Graph spatial-lag view": ["graph"],
    }

    for fold, (train_idx, test_idx) in enumerate(outer.split(labelled, y, groups), start=1):
        x_train, x_test = labelled.iloc[train_idx], labelled.iloc[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        view_data = base.inner_view_predictions(
            x_train, y_train, groups[train_idx], x_test, seed + 100 * fold
        )
        for name, views in variants.items():
            pred, spread, weights = base.predict_variant(
                view_data, x_train, y_train, x_test, views, True, False
            )
            rec = {
                "fold": fold,
                "model": name,
                "n_train": len(train_idx),
                "n_test": len(test_idx),
                "held_out_states": "; ".join(sorted(x_test[base.GROUP].unique())),
                **metrics(y_test, pred),
            }
            records.append(rec)
            for pos, p, s in zip(test_idx, pred, spread):
                preds.append({
                    "objectid": int(labelled.loc[pos, "objectid"]),
                    "state_canonical": labelled.loc[pos, base.GROUP],
                    "fold": fold,
                    "model": name,
                    "y_true": float(labelled.loc[pos, base.TARGET]),
                    "y_pred": float(p),
                    "absolute_error": float(abs(labelled.loc[pos, base.TARGET] - p)),
                    "ensemble_spread": float(s),
                })

    base.VIEW_FEATURES = original_views
    folds = pd.DataFrame(records)
    summary = folds.groupby("model", sort=False).agg(
        folds=("fold", "count"),
        mae_mean=("mae", "mean"), mae_std=("mae", "std"),
        rmse_mean=("rmse", "mean"), rmse_std=("rmse", "std"),
        r2_mean=("r2", "mean"), r2_std=("r2", "std"),
    ).reset_index().sort_values("rmse_mean")
    return folds, summary, pd.DataFrame(preds)


def main():
    data = pd.read_csv(PKG / "data/processed/cement_flyash_model_dataset.csv")
    tpp = pd.read_csv(PKG / "data/raw/CEA_Thermal_Power_Plants_2024_25.csv")
    out = PKG / "results/graph_extension"
    out.mkdir(parents=True, exist_ok=True)
    all_runs = []
    best = None
    for tau, top_k in [(75.0, 8), (100.0, 12), (150.0, 16)]:
        graph = build_graph_features(data, tpp, tau_km=tau, top_k=top_k)
        augmented = pd.concat([data.reset_index(drop=True), graph], axis=1)
        graph_cols = list(graph.columns)
        folds, summary, preds = evaluate(augmented, graph_cols)
        summary.insert(0, "tau_km", tau)
        summary.insert(1, "top_k", top_k)
        all_runs.append(summary)
        score = float(summary.loc[summary["model"] == "CFA-RGSE-GSL (graph-augmented)", "rmse_mean"].iloc[0])
        if best is None or score < best[0]:
            best = (score, tau, top_k, graph, folds, summary, preds)
        print(f"tau={tau:g} top_k={top_k}\n{summary.to_string(index=False)}\n", flush=True)

    assert best is not None
    score, tau, top_k, graph, folds, summary, preds = best
    pd.concat(all_runs, ignore_index=True).to_csv(out / "graph_configuration_summary.csv", index=False)
    graph.to_csv(out / "graph_features_best.csv", index=False)
    folds.to_csv(out / "graph_fold_metrics_best.csv", index=False)
    summary.to_csv(out / "graph_summary_best.csv", index=False)
    preds.to_csv(out / "graph_oof_predictions_best.csv", index=False)
    with (out / "graph_manifest.json").open("w", encoding="utf-8") as f:
        json.dump({
            "selected_tau_km": tau,
            "selected_top_k": top_k,
            "selection_note": "Exploratory sensitivity across three predeclared graph scales; not a nested hyperparameter claim.",
            "target_excluded_from_graph": True,
            "graph_inputs": "cement/TPP coordinates, TPP capacity/pithead class, plant geometry, state fly-ash aggregates, and source-quality covariates",
            "best_graph_augmented_rmse": score,
        }, f, indent=2)
    print("BEST", tau, top_k, score)


if __name__ == "__main__":
    main()
