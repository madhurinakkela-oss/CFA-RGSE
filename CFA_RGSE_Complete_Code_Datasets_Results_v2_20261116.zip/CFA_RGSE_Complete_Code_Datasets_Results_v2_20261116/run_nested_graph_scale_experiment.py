#!/usr/bin/env python3
"""Nested state-grouped selection of target-free graph scale for CFA-RGSE-GSL."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GroupKFold

ROOT = Path(__file__).resolve().parent
PKG = ROOT / "cfa_pkg"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(PKG / "scripts"))

import train_capacity_models as base  # noqa: E402
from run_graph_spatial_lag_experiment import build_graph_features  # noqa: E402

CANDIDATES = [(75.0, 8), (100.0, 12), (150.0, 16)]
MODEL = "CFA-RGSE-GSL nested no fly-ash"


def active_view_map(graph_cols):
    return {
        "plant": base.CORE_FEATURES,
        "tpp": base.CORE_FEATURES + base.TPP_FEATURES,
        "major": base.CORE_FEATURES + base.MAJOR_FEATURES,
        "graph": base.CORE_FEATURES + list(graph_cols),
    }


def predict_split(train, test, seed, graph_cols):
    original = dict(base.VIEW_FEATURES)
    base.VIEW_FEATURES = active_view_map(graph_cols)
    y_train = train[base.TARGET].to_numpy(float)
    groups = train[base.GROUP].to_numpy()
    view_data = base.inner_view_predictions(train, y_train, groups, test, seed)
    pred, spread, weights = base.predict_variant(
        view_data, train, y_train, test,
        ["plant", "tpp", "major", "graph"], True, False,
    )
    base.VIEW_FEATURES = original
    return pred, spread, weights


def select_candidate(train_indices, candidate_frames, outer_fold):
    reference = next(iter(candidate_frames.values())).iloc[train_indices].reset_index(drop=True)
    groups = reference[base.GROUP].to_numpy()
    y = reference[base.TARGET].to_numpy(float)
    inner = GroupKFold(n_splits=min(3, len(np.unique(groups))))
    scores = {}
    for candidate, frame in candidate_frames.items():
        subset = frame.iloc[train_indices].reset_index(drop=True)
        graph_cols = [c for c in subset.columns if c.startswith("graph_")]
        truth, estimates = [], []
        for inner_fold, (fit_idx, val_idx) in enumerate(inner.split(subset, y, groups), start=1):
            pred, _spread, _weights = predict_split(
                subset.iloc[fit_idx].reset_index(drop=True),
                subset.iloc[val_idx].reset_index(drop=True),
                seed=base.SEED + outer_fold*10000 + inner_fold*100,
                graph_cols=graph_cols,
            )
            truth.append(y[val_idx]); estimates.append(pred)
        truth = np.concatenate(truth); estimates = np.concatenate(estimates)
        scores[candidate] = float(math.sqrt(mean_squared_error(truth, estimates)))
    return min(scores, key=scores.get), scores


def main():
    data = pd.read_csv(PKG / "data/processed/cement_flyash_model_dataset.csv")
    tpp = pd.read_csv(PKG / "data/raw/CEA_Thermal_Power_Plants_2024_25.csv")
    candidate_frames = {}
    for candidate in CANDIDATES:
        tau, top_k = candidate
        graph = build_graph_features(data, tpp, tau_km=tau, top_k=top_k)
        candidate_frames[candidate] = pd.concat([data.reset_index(drop=True), graph], axis=1)

    labelled_idx = np.flatnonzero(data[base.TARGET].notna().to_numpy())
    labelled_reference = data.iloc[labelled_idx].reset_index(drop=True)
    groups = labelled_reference[base.GROUP].to_numpy()
    y = labelled_reference[base.TARGET].to_numpy(float)
    outer = GroupKFold(n_splits=5)
    fold_rows, pred_rows, selection_rows = [], [], []

    for outer_fold, (train_rel, test_rel) in enumerate(outer.split(labelled_reference, y, groups), start=1):
        train_abs = labelled_idx[train_rel]
        test_abs = labelled_idx[test_rel]
        selected, scores = select_candidate(train_abs, candidate_frames, outer_fold)
        tau, top_k = selected
        frame = candidate_frames[selected]
        train = frame.iloc[train_abs].reset_index(drop=True)
        test = frame.iloc[test_abs].reset_index(drop=True)
        graph_cols = [c for c in frame.columns if c.startswith("graph_")]
        pred, spread, weights = predict_split(
            train, test, seed=base.SEED + outer_fold*1000, graph_cols=graph_cols
        )
        y_test = data.iloc[test_abs][base.TARGET].to_numpy(float)
        fold_rows.append({
            "fold": outer_fold, "model": MODEL,
            "selected_tau_km": tau, "selected_top_k": top_k,
            "n_train": len(train_abs), "n_test": len(test_abs),
            "held_out_states": "; ".join(sorted(data.iloc[test_abs][base.GROUP].unique())),
            "mae": float(mean_absolute_error(y_test, pred)),
            "rmse": float(math.sqrt(mean_squared_error(y_test, pred))),
            "r2": float(r2_score(y_test, pred)),
        })
        selection_rows.append({
            "fold": outer_fold, "selected_tau_km": tau, "selected_top_k": top_k,
            **{f"inner_rmse_tau_{int(k[0])}_k_{k[1]}": v for k,v in scores.items()},
        })
        for local_i, abs_i, p, s in zip(range(len(test_abs)), test_abs, pred, spread):
            pred_rows.append({
                "objectid": int(data.iloc[abs_i].objectid),
                "state_canonical": data.iloc[abs_i][base.GROUP],
                "fold": outer_fold, "model": MODEL,
                "selected_tau_km": tau, "selected_top_k": top_k,
                "y_true": float(y_test[local_i]), "y_pred": float(p),
                "absolute_error": float(abs(y_test[local_i]-p)),
                "ensemble_spread": float(s),
            })
        print(f"outer fold {outer_fold}: selected tau={tau:g}, k={top_k}; RMSE={fold_rows[-1]['rmse']:.4f}", flush=True)

    folds = pd.DataFrame(fold_rows)
    preds = pd.DataFrame(pred_rows)
    selections = pd.DataFrame(selection_rows)
    summary = pd.DataFrame([{
        "model": MODEL, "folds": len(folds),
        "mae_mean": folds.mae.mean(), "mae_std": folds.mae.std(ddof=1),
        "rmse_mean": folds.rmse.mean(), "rmse_std": folds.rmse.std(ddof=1),
        "r2_mean": folds.r2.mean(), "r2_std": folds.r2.std(ddof=1),
    }])
    out = PKG / "results/nested_graph_extension"
    out.mkdir(parents=True, exist_ok=True)
    folds.to_csv(out / "nested_graph_fold_metrics.csv", index=False)
    preds.to_csv(out / "nested_graph_oof_predictions.csv", index=False)
    selections.to_csv(out / "nested_graph_scale_selections.csv", index=False)
    summary.to_csv(out / "nested_graph_summary.csv", index=False)
    (out / "nested_graph_manifest.json").write_text(json.dumps({
        "outer_evaluation": "5-fold state-held-out GroupKFold",
        "graph_scale_selection": "3-fold state-grouped CV within each outer-training partition",
        "candidates": [{"tau_km": t, "top_k": k} for t,k in CANDIDATES],
        "target_excluded_from_graph": True,
        "graph_scope": "registry-transductive covariates; held-out target labels excluded",
    }, indent=2), encoding="utf-8")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
