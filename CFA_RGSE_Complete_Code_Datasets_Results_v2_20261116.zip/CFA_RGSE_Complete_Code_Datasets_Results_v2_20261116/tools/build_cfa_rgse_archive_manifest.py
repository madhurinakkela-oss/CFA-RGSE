#!/usr/bin/env python3
"""Create deterministic file inventory and SHA-256 records for the archive."""

from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path


EXCLUDED = {"FILE_MANIFEST.csv", "SHA256SUMS.txt", "PACKAGE_MANIFEST.json"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("Usage: build_cfa_rgse_archive_manifest.py PACKAGE_DIRECTORY")
    root = Path(sys.argv[1]).resolve()
    if not root.is_dir():
        raise SystemExit(f"Not a directory: {root}")

    rows = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.name in EXCLUDED:
            continue
        rel = path.relative_to(root).as_posix()
        rows.append({"path": rel, "size_bytes": path.stat().st_size, "sha256": sha256(path)})

    with (root / "FILE_MANIFEST.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["path", "size_bytes", "sha256"])
        writer.writeheader()
        writer.writerows(rows)

    (root / "SHA256SUMS.txt").write_text(
        "".join(f"{row['sha256']}  {row['path']}\n" for row in rows), encoding="utf-8"
    )
    categories: dict[str, int] = {}
    for row in rows:
        category = row["path"].split("/", 1)[0]
        categories[category] = categories.get(category, 0) + 1
    manifest = {
        "package_name": root.name,
        "package_date": "2026-11-16",
        "file_count_excluding_manifest_files": len(rows),
        "total_bytes_excluding_manifest_files": sum(int(row["size_bytes"]) for row in rows),
        "files_by_top_level_category": categories,
        "validation_report": "VALIDATION_REPORT.json",
        "checksum_scope_note": (
            "FILE_MANIFEST.csv, SHA256SUMS.txt, and PACKAGE_MANIFEST.json are excluded "
            "from the recursive checksum list to avoid self-reference."
        ),
    }
    (root / "PACKAGE_MANIFEST.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
