#!/usr/bin/env python3
"""Validate data counts, key reported results, and required artifacts."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parent
PKG = ROOT / "cfa_pkg"
REPORT = ROOT / "VALIDATION_REPORT.json"


def close(value: float, target: float, tolerance: float = 5e-4) -> bool:
    return math.isfinite(float(value)) and abs(float(value) - target) <= tolerance


def main() -> None:
    checks: list[dict[str, object]] = []

    def record(name: str, passed: bool, observed: object, expected: object) -> None:
        checks.append(
            {"check": name, "passed": bool(passed), "observed": observed, "expected": expected}
        )

    raw = PKG / "data/raw"
    expected_rows = {
        "Cement_Plants_in_India_2024.csv": 380,
        "CEA_Thermal_Power_Plants_2024_25.csv": 189,
        "CEA_Statewise_Fly_Ash_2024_25.csv": 18,
        "CEA_Major_Cement_Plants_2025.csv": 141,
    }
    for name, expected in expected_rows.items():
        observed = len(pd.read_csv(raw / name))
        record(f"raw_rows:{name}", observed == expected, observed, expected)

    dataset = pd.read_csv(PKG / "data/processed/cement_flyash_model_dataset.csv")
    record("processed_shape", tuple(dataset.shape) == (380, 53), list(dataset.shape), [380, 53])
    capacity_labels = int(dataset["capacity_mtpa_target"].notna().sum())
    production_labels = int(dataset["production_mt_target"].notna().sum())
    record("capacity_labels", capacity_labels == 272, capacity_labels, 272)
    record("production_labels", production_labels == 115, production_labels, 115)

    summary = pd.read_csv(PKG / "results/capacity_group_cv_summary.csv")
    core = summary.loc[summary["model"].eq("CFA-RGSE (full)")].iloc[0]
    rf = summary.loc[summary["model"].eq("RandomForest")].iloc[0]
    no_fly = summary.loc[summary["model"].eq("w/o fly-ash view")].iloc[0]
    record("core_capacity_rmse", close(core.rmse_mean, 1.302564), float(core.rmse_mean), 1.302564)
    record("random_forest_rmse", close(rf.rmse_mean, 1.319943), float(rf.rmse_mean), 1.319943)
    record("no_flyash_rmse", close(no_fly.rmse_mean, 1.298014), float(no_fly.rmse_mean), 1.298014)

    missing = pd.read_csv(PKG / "results/capacity_missing_predictions.csv")
    priority = pd.read_csv(PKG / "results/cement_flyash_linkage_priority.csv")
    record("capacity_completions", len(missing) == 108, len(missing), 108)
    record("priority_file_rows", len(priority) == 380, len(priority), 380)
    scored_rows = int(priority["linkage_priority_score"].notna().sum())
    record("priority_scored_rows", scored_rows == 341, scored_rows, 341)

    nested_path = PKG / "results/nested_graph_extension/nested_graph_summary.csv"
    if nested_path.exists():
        nested = pd.read_csv(nested_path).iloc[0]
        record("nested_graph_rmse", close(nested.rmse_mean, 1.295244), float(nested.rmse_mean), 1.295244)

    links_path = PKG / "results/q1_extension/baseline_mass_balance_links.csv"
    if links_path.exists():
        links = pd.read_csv(links_path)
        allocated = float(links["allocated_mt"].sum())
        record("allocation_positive_links", len(links) == 113, len(links), 113)
        record("allocation_total_mt", close(allocated, 24.260, 5e-6), allocated, 24.260)

    required_plots = [
        PKG / "results/plots/capacity_actual_vs_predicted.png",
        PKG / "results/plots/production_actual_vs_predicted.png",
        PKG / "results/plots/capacity_prediction_map.png",
        ROOT / "output/q1_extension_figures/Fig10_Graph_Benchmark_and_Uncertainty.png",
        ROOT / "output/q1_extension_figures/Fig11_Mass_Balance_Pareto_Screen.png",
        ROOT / "output/q1_extension_figures/Fig12_Scenario_Geospatial_Stress_Surfaces.png",
    ]
    for plot in required_plots:
        observed = plot.stat().st_size if plot.exists() else 0
        record(f"nonempty_plot:{plot.relative_to(ROOT)}", observed > 0, observed, "> 0 bytes")

    passed = all(bool(item["passed"]) for item in checks)
    payload = {
        "package": "CFA-RGSE complete reproducibility package",
        "validation_status": "PASS" if passed else "FAIL",
        "checks_total": len(checks),
        "checks_passed": sum(bool(item["passed"]) for item in checks),
        "checks": checks,
    }
    REPORT.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))
    if not passed:
        sys.exit(1)


if __name__ == "__main__":
    main()
